'''
@file:    self_learning.py
@company: Hiwonder
@author:  CuZn
@date:    2023-08-24
@description: 自主学习(self learning)
'''

'''
此示例展示利用KPU神经网络,进行自分类学习的功能。(This example demonstrates on how to use a KPU neural network to perform the self-classification learning)
它共有三种模式：初始化、训练、分类(It has three modes: initialization, training, and classification)
操作指南(operating instructions)：
1. 初始化模式：按下boot键，进入初始化模式，此时屏幕显示“Init”。(Initialization Mode: press the boot button to enter the initialization mode. The screen will display "Init" at this time)
2. 训练模式：按下boot键，进入训练模式，此时屏幕显示“Train object 1”。(Training Mode: press the boot button to enter the training mode. The screen will display "Train object 1")
    按下boot键，拍摄一张图片，屏幕显示“Train object 1\r\n\r\nBoot key to take #P2”。(Press the boot button to capture an image. The screen will display "Train object 1\r\n\r\nBoot key to take #P2")
    按下boot键，拍摄一张图片，屏幕显示“Train object 1\r\n\r\nBoot key to take #P3”。(Press the boot button to capture an image. The screen will display "Train object 1\r\n\r\nBoot key to take #P3")
3. 分类模式：按下boot键，进入分类模式，此时屏幕显示“Classification”。(Classification Mode: press the boot button to enter the classification mode. The screen will display "Classification")

'''


#导入所需的库(import the required libraries)
import lcd
import sensor
import time
from maix import GPIO
from maix import KPU
from board import board_info
from fpioa_manager import fm
from image import Image
from hiwonder import hw_key



# 定义状态枚举类 STATE，用于标识状态(Define the enumeration class STATE to identify states)
class STATE(object):
    IDLE = 0          # 空闲状态(idle state)
    INIT = 1          # 初始化状态(initial state)
    TRAIN_CLASS_1 = 2 # 训练类别 1 状态(training state for class 1)
    TRAIN_CLASS_2 = 3 # 训练类别 2 状态(training state for class 2)
    TRAIN_CLASS_3 = 4 # 训练类别 3 状态(training state for class 3)
    CLASSIFY = 5      # 分类状态(classification state)
    STATE_MAX = 6     # 状态的最大值(the maximum value for state)

# 定义事件枚举类 EVENT，用于标识事件(define the enumeration class EVENT to identify events)
class EVENT(object):
    POWER_ON = 0            # 上电事件(power-on event)
    BOOT_KEY = 1            # 按下启动键事件(boot button press event)
    BOOT_KEY_LONG_PRESS = 2 # 长按启动键事件(boot button long press event)
    EVENT_NEXT_MODE = 3     # 切换到下一个模式事件(switch to the next mode event)
    EVENT_MAX = 4           # 事件的最大值(the maximum value for event)


# 定义状态机类 StateMachine(Define state machine class StateMachine)
class StateMachine(object):
    def __init__(self, state_handlers, event_handlers, transitions):
        # 初始状态为IDLE(initial state is IDLE)
        self.previous_state = STATE.IDLE
        self.current_state = STATE.IDLE
        # 存储状态处理函数、事件处理函数和状态转换的列表(Store lists of state handle function, event handle function, and state transition)
        self.state_handlers = state_handlers
        self.event_handlers = event_handlers
        self.transitions = transitions

    # 重置状态机(reset state machine)
    def reset(self):
        self.previous_state = STATE.IDLE
        self.current_state = STATE.IDLE


    '''
    #根据当前状态和事件从状态转换表中查找下一个状态(find the next state based on the current state and event from the transition table)
    #根据当着状态和event, 从transitions表里查找出下一个状态(look up the next state based on the current state and event in the transitions table)
        param cur_state:
        param cur_event:
        return:
            next_state: 下一状态(the current state)
            None: 找不到对应状态(if no corresponding state is found)
    '''
    def get_next_state(self, cur_state, cur_event):

        for cur, next, event in self.transitions:
            if cur == cur_state and event == cur_event:
                return next
        return None

    '''
    执行当前状态对应的进入action(execute the entry action corresponding to the current state)
        param state: 当前状态(the current state)
        param event: 当前event(the current event)
    '''
    def enter_state_action(self, state, event):
        try:
            if self.state_handlers[state][0]:
                self.state_handlers[state][0](self, state, event)
        except Exception as e:
            print(e)


    '''
    执行当前状态action函数(execute the current state action function)
        param state:   当前状态(the current state)
        param event:   当前event(the current event)
    '''
    def execute_state_action(self, state, event):

        try:
            if self.state_handlers[state][1]:
                self.state_handlers[state][1](self, state, event)
        except Exception as e:
            print(e)


    '''
    执行当前状态的退出action(execute the exiting action of the current state)
        param state: 当前状态(the current state)
        param event: 当前event(the current event)
    '''
    def exit_state_action(self, state, event):

        try:
            if self.state_handlers[state][2]:
                self.state_handlers[state][2](self, state, event)
        except Exception as e:
            print(e)


    '''
    发送event。根据当前状态和event，查找下一个状态，然后执行对应的action。(Send an event. Find the next state based on the current state and event, then execute the corresponding action)
        param event: 要发送的event(the event to be sent)
    '''
    def emit_event(self, event):

        next_state = self.get_next_state(self.current_state, event)

        # 当状态发生改变时，执行退出和进入动作(When the state changes, execute the exit and entry actions)
        if next_state != None and next_state != self.current_state:
            self.exit_state_action(self.previous_state, event)
            self.previous_state = self.current_state
            self.current_state = next_state
            self.enter_state_action(self.current_state, event)
            print("event valid: {}, cur: {}, next: {}".format(event, self.current_state, next_state))

        # 执行当前状态的动作(execute the action of the current state)
        self.execute_state_action(self.current_state, event)


    #状态机引擎，用于执行状态机(State machine engine utilized for the execution of the state machine)
    def engine(self):
        pass


# 重新启动状态机程序(restart state machine program)
def restart(self):
    global features
    self.reset()
    features.clear()
    self.emit_event(EVENT.POWER_ON)


# 进入空闲状态时的动作(the action performed upon entering the idle state)
def enter_state_idle(self, state, event):
    print("enter state: idle")


# 退出空闲状态时的动作(the action performed upon exiting the idle state)
def exit_state_idle(self, state, event):
    print("exit state: idle")


# 空闲状态的动作(the action of the idle state)
def state_idle(self, state, event):
    global central_msg
    print("current state: idle")
    central_msg = None


# 进入初始化状态时的动作(the action performed upon entering the initial state)
def enter_state_init(self, state, event):
    global img_init
    print("enter state: init")
    img_init = Image(size=(lcd.width(), lcd.height()))


# 退出初始化状态时的动作(the action performed upon exiting the initial state)
def exit_state_init(self, state, event):
    print("exit state: init")
    del img_init


# 初始化状态的动作(the action of the initial state)
def state_init(self, state, event):
    print("current state: init, event: {}".format(event))

    # 当按下启动键时，发送切换到下一个模式的事件(When the boot button is pressed, send the event of switching to the next mode)
    if event == EVENT.BOOT_KEY:
        self.emit_event(EVENT.EVENT_NEXT_MODE)
    # 当长按启动键时，重新启动状态机(When the boot button is long pressed, restart the state machine)
    elif event == EVENT.BOOT_KEY_LONG_PRESS:
        restart(self)
        return


# 进入训练类别 1 状态时的动作(the action when enters the training class 1 state)
def enter_state_train_class_1(self, state, event):
    print("enter state: train class 1")
    global train_pic_cnt, central_msg, bottom_msg
    train_pic_cnt = 0
    central_msg = "Train class 1"
    bottom_msg = "Take pictures of 1st class"


# 退出训练类别 1 状态时的动作(the action when exits the training class 1 state)
def exit_state_train_class_1(self, state, event):
    print("exit state: train class 1")


# 训练类别 1 状态的动作(the action of training class 1 state)
def state_train_class_1(self, state, event):
    global kpu, central_msg, bottom_msg, features, train_pic_cnt
    global state_machine
    print("current state: class 1")

    if event == EVENT.BOOT_KEY_LONG_PRESS:
        restart(self)
        return

    if train_pic_cnt == 0:  # 这里的0仅用于提示(the 0 is used for prompting)
        features.append([]) # 添加一个空的特征列表(add an empty feature list)
        train_pic_cnt += 1
    elif train_pic_cnt <= max_train_pic:
        central_msg = None
        img = sensor.snapshot() # 获取一张图像(obtain an image)
        feature = kpu.run_with_output(img, get_feature=True) # 提取图像特征(extract image feature)
        features[0].append(feature) # 将特征添加到特征列表中
        bottom_msg = "Class 1: #P{}".format(train_pic_cnt) # 在屏幕底部显示消息(display the message on the bottom of the screen)
        train_pic_cnt += 1
    else:
        state_machine.emit_event(EVENT.EVENT_NEXT_MODE) # 发送切换到下一个模式的事件(send the event of switching to the next mode)


# 进入训练类别 2 状态时的动作(the action when enters the training class 2 state)
def enter_state_train_class_2(self, state, event):
    print("enter state: train class 2")
    global train_pic_cnt, central_msg, bottom_msg
    train_pic_cnt = 0
    central_msg = "Train class 2"
    bottom_msg = "Change to 2nd class please"


# 退出训练类别 2 状态时的动作(the action when exits the training class 2 state)
def exit_state_train_class_2(self, state, event):
    print("exit state: train class 2")


# 训练类别 2 状态的动作(the action of training class 2 state)
def state_train_class_2(self, state, event):
    global kpu, central_msg, bottom_msg, features, train_pic_cnt
    global state_machine
    print("current state: class 2")

    if event == EVENT.BOOT_KEY_LONG_PRESS:
        restart(self)
        return

    if train_pic_cnt == 0:
        features.append([])
        train_pic_cnt += 1
    elif train_pic_cnt <= max_train_pic:
        central_msg = None
        img = sensor.snapshot()
        feature = kpu.run_with_output(img, get_feature=True)
        features[1].append(feature)
        bottom_msg = "Class 2: #P{}".format(train_pic_cnt)
        train_pic_cnt += 1
    else:
        state_machine.emit_event(EVENT.EVENT_NEXT_MODE)


# 进入训练类别 3 状态时的动作(the action when enters the training class 3 state)
def enter_state_train_class_3(self, state, event):
    print("enter state: train class 3")
    global train_pic_cnt, central_msg, bottom_msg
    train_pic_cnt = 0
    central_msg = "Train class 3"
    bottom_msg = "Change to 3rd class please"


# 退出训练类别 3 状态时的动作(the action when exits the training class 3 state)
def exit_state_train_class_3(self, state, event):
    print("exit state: train class 3")


# 训练类别 3 状态的动作(the action of training class 3 state)
def state_train_class_3(self, state, event):
    global kpu, central_msg, bottom_msg, features, train_pic_cnt
    global state_machine
    print("current state: class 3")

    if event == EVENT.BOOT_KEY_LONG_PRESS:
        restart(self)
        return

    if train_pic_cnt == 0:
        features.append([])
        train_pic_cnt += 1
    elif train_pic_cnt <= max_train_pic:
        central_msg = None
        img = sensor.snapshot()
        feature = kpu.run_with_output(img, get_feature=True)
        features[2].append(feature)
        bottom_msg = "Class 3: #P{}".format(train_pic_cnt)
        train_pic_cnt += 1
    else:
        state_machine.emit_event(EVENT.EVENT_NEXT_MODE)


# 进入分类状态时的动作(the action when enters the classification state)
def enter_state_classify(self, state, event):
    global central_msg, bottom_msg
    print("enter state: classify")
    central_msg = "Classification"
    bottom_msg = "Training complete! Start classification"



# 退出分类状态时的动作(the action when exits the classification state)
def exit_state_classify(self, state, event):
    print("exit state: classify")


# 分类状态的动作(the action of the classification state)
def state_classify(self, state, event):
    global central_msg, bottom_msg
    print("current state: classify, {}, {}".format(state, event))
    if event == EVENT.BOOT_KEY:
        central_msg = None
    if event == EVENT.BOOT_KEY_LONG_PRESS:
        restart(self)
        return


# 发送上电事件(send power-on event)
def event_power_on(self, value=None):
    print("emit event: power_on")


# 发送按下启动键事件(send press boot button event)
def event_press_boot_key(self, value=None):
    global state_machine
    print("emit event: boot_key")


# 发送长按启动键事件(send long press boot button event)
def event_long_press_boot_key(self, value=None):
    global state_machine
    print("emit event: boot_key_long_press")



# 状态动作表格式:(state-action table format)
# state: [进入状态处理函数, 执行状态处理函数, 退出状态处理函数(enter state handle function, execute state handle function, and exit state handle function)]
state_handlers = {
    STATE.IDLE: [enter_state_idle, state_idle, exit_state_idle],
    STATE.INIT: [enter_state_init, state_init, exit_state_init],
    STATE.TRAIN_CLASS_1: [enter_state_train_class_1, state_train_class_1, exit_state_train_class_1],
    STATE.TRAIN_CLASS_2: [enter_state_train_class_2, state_train_class_2, exit_state_train_class_2],
    STATE.TRAIN_CLASS_3: [enter_state_train_class_3, state_train_class_3, exit_state_train_class_3],
    STATE.CLASSIFY: [enter_state_classify, state_classify, exit_state_classify]
}


# 事件动作表，根据需要在需要时启用(Event-action table, enabling as needed)
event_handlers = {
    EVENT.POWER_ON: event_power_on,
    EVENT.BOOT_KEY: event_press_boot_key,
    EVENT.BOOT_KEY_LONG_PRESS: event_long_press_boot_key
}


# 过渡表(transition table)
transitions = [
    [STATE.IDLE, STATE.INIT, EVENT.POWER_ON],
    [STATE.INIT, STATE.TRAIN_CLASS_1, EVENT.EVENT_NEXT_MODE],
    [STATE.TRAIN_CLASS_1, STATE.TRAIN_CLASS_2, EVENT.EVENT_NEXT_MODE],
    [STATE.TRAIN_CLASS_2, STATE.TRAIN_CLASS_3, EVENT.EVENT_NEXT_MODE],
    [STATE.TRAIN_CLASS_3, STATE.CLASSIFY, EVENT.EVENT_NEXT_MODE]
]


####################################################################################################################
class Button(object):
    DEBOUNCE_THRESHOLD = 30      # 消抖阈值 debounce threshold(ms)
    LONG_PRESS_THRESHOLD = 1000  # 长按阈值 long press threshold(ms)
    # 内部按键状态(internal button states)
    IDLE = 0
    DEBOUNCE = 1
    SHORT_PRESS = 2
    LONG_PRESS = 3

    def __init__(self, state_machine):
        self._state = Button.IDLE
        self._key_ticks = 0
        self._pre_key_state = 1
        self.SHORT_PRESS_BUF = None
        self.st = state_machine

    #重置按键状态(reset button states)
    def reset(self):
        self._state = Button.IDLE
        self._key_ticks = 0
        self._pre_key_state = 1
        self.SHORT_PRESS_BUF = None

    '''
    按键抬起时的处理(processing when a button is released)
        param delta: 按键抬起时间间隔(the time interval when the button is released)
    '''
    def key_up(self, delta):
        if self.SHORT_PRESS_BUF:
            self.st.emit_event(self.SHORT_PRESS_BUF)
        self.reset()

    '''
    按键按下时的处理(processing when the button is pressed)
        param delta: 按键按下时间间隔(the time interval when the button is pressed)
    '''
    def key_down(self, delta):
        # print("dn:{},t:{}".format(delta, self._key_ticks))
        if self._state == Button.IDLE:
            self._key_ticks += delta
            if self._key_ticks > Button.DEBOUNCE_THRESHOLD:
                # main loop period过大时，会直接跳过去抖阶段(If the main loop period is too large, it may result in the direct skipping of the debounce stage)
                self._state = Button.SHORT_PRESS
                self.SHORT_PRESS_BUF = EVENT.BOOT_KEY  # 按键抬起时发送事件(send an event upon button release)
            else:
                self._state = Button.DEBOUNCE
        elif self._state == Button.DEBOUNCE:
            self._key_ticks += delta
            if self._key_ticks > Button.DEBOUNCE_THRESHOLD:
                self._state = Button.SHORT_PRESS
                self.SHORT_PRESS_BUF = EVENT.BOOT_KEY  # 按键抬起时发送事件(send an event upon button release)
        elif self._state == Button.SHORT_PRESS:
            self._key_ticks += delta
            if self._key_ticks > Button.LONG_PRESS_THRESHOLD:
                self._state = Button.LONG_PRESS
                self.SHORT_PRESS_BUF = None
                self.st.emit_event(EVENT.BOOT_KEY_LONG_PRESS) # 长按事件(long press event)
        elif self._state == Button.LONG_PRESS:
            self._key_ticks += delta
            # 最迟 LONG_PRESS 发出信号，再以后就忽略，不需要处理。key_up时再退出状态机。(The LONG_PRESS signal should be emitted at the latest, and any subsequent signals should be ignored without further processing. Exiting the state machine should only occur when key_up is detected)
            pass
        else:
            pass


####################################################################################################################
# 未启用 state machine 的主循环，所以这里将需要循环执行的函数放在while True里(The function that needs to be executed in a loop can be placed within a while True loop since there is no state machine's main loop enabled)
def loop_init():
    if state_machine.current_state != STATE.INIT:
        return

    # 在初始阶段绘制图像(draw image at the initial stage)
    img_init.draw_rectangle(0, 0, lcd.width(), lcd.height(), color=(0, 0, 255), fill=True, thickness=2)
    img_init.draw_string(65, 90, "Self Learning Demo", color=(255, 255, 255), scale=2)
    img_init.draw_string(5, 210, "Short press:  next", color=(255, 255, 255), scale=1)
    img_init.draw_string(5, 225, "Long press:    restart", color=(255, 255, 255), scale=1)
    lcd.display(img_init)


#捕获阶段的循环函数(the loop function at the capturing stage)
def loop_capture():
    global central_msg, bottom_msg
    img = sensor.snapshot()

    # 在捕获阶段显示提示信息(display the prompt message at the capturing stage)
    if central_msg:
        img.draw_rectangle(0, 90, lcd.width(), 22, color=(0, 0, 255), fill=True, thickness=2)
        img.draw_string(55, 90, central_msg, color=(255, 255, 255), scale=2)
    if bottom_msg:
        img.draw_string(5, 208, bottom_msg, color=(0, 0, 255), scale=1)
    lcd.display(img)


#分类阶段的循环函数(the loop function of the classification stage)
def loop_classify():
    global central_msg, bottom_msg
    img = sensor.snapshot()

    scores = []
    feature = kpu.run_with_output(img, get_feature=True)
    high = 0
    index = 0
    for j in range(len(features)):
        for f in features[j]:
            score = kpu.feature_compare(f, feature)
            if score > high:
                high = score
                index = j
    if high > THRESHOLD:
        bottom_msg = "class:{},score:{:2.1f}".format(index + 1, high)
    else:
        bottom_msg = None

    # 显示分类结果信息(display the classification result information)
    if central_msg:
        print("central_msg:{}".format(central_msg))
        img.draw_rectangle(0, 90, lcd.width(), 22, color=(0, 255, 0), fill=True, thickness=2)
        img.draw_string(55, 90, central_msg, color=(255, 255, 255), scale=2)
    if bottom_msg:
        print("bottom_msg:{}".format(bottom_msg))
        img.draw_string(5, 208, bottom_msg, color=(0, 255, 0), scale=1)
    lcd.display(img)

####################################################################################################################
# main loop
features = []
THRESHOLD = 98.5    # 比对阈值，越大越严格(Comparative threshold, the higher the value, the stricter it is)
train_pic_cnt = 0   # 当前分类已训练图片数量(Current number of trained images in the classification)
max_train_pic = 5   # 每个类别最多训练图片数量(Maximum number of training images per category)

central_msg = None  # 屏幕中间显示的信息(information displayed in the middle of the screen)
bottom_msg = None   # 屏幕底部显示的信息(information displayed at the bottom of the screen)



# 创建按键对象(create button object)
boot_gpio = hw_key()

# 初始化LCD和图像传感器(initialize the LCD and image sensor)
lcd.init()
sensor.reset()
sensor.set_pixformat(sensor.RGB565)
sensor.set_framesize(sensor.QVGA)
sensor.set_windowing((224, 224))
sensor.skip_frames(time=100)


# 初始化KPU模型(initialize the KPU model)
kpu = KPU()
print("ready load model")
kpu.load_kmodel("/sd/KPU/self_learn_classifier/mb-0.25.kmodel")


# 初始化状态机(initialize state machine)
state_machine = StateMachine(state_handlers, event_handlers, transitions)
state_machine.emit_event(EVENT.POWER_ON)

btn_ticks_prev = time.ticks_ms()
boot_btn = Button(state_machine)

while True:
    btn_ticks_cur = time.ticks_ms()
    delta = time.ticks_diff(btn_ticks_cur, btn_ticks_prev)
    btn_ticks_prev = btn_ticks_cur

    # 检测引脚状态以检测按键动作(detect pins state to detect button action)
    if boot_gpio.key_scan(2) == 1:
        boot_btn.key_down(delta)
    else:
        boot_btn.key_up(delta)


    # 根据状态执行不同的循环函数(execute different loop functions based on the state)
    if state_machine.current_state == STATE.INIT:
        loop_init()
    elif state_machine.current_state == STATE.CLASSIFY:
        loop_classify()
    elif state_machine.current_state == STATE.TRAIN_CLASS_1 \
            or state_machine.current_state == STATE.TRAIN_CLASS_2 \
            or state_machine.current_state == STATE.TRAIN_CLASS_3:
        loop_capture()

