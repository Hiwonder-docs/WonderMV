'''
@file:    find_face_recog.py
@company: Hiwonder
@author:  CuZn
@date:    2023-08-26
@description: 人脸识别，并将识别后的数据发送给 开发板（STM32等）(Perform face recognition and send the recognized data to a development board such as STM32)
        # K210视觉模块 会将识别到的方框数据和识别信息 通过串口 发送给 开发板（STM32等）(The K210 vision module sends the data of the recognized box and detection result to a development board, such as STM32, via the serial port)

'''

#载入相关模块(load relevant models)
import sensor, image, time, lcd
import gc
from maix import KPU
from maix import GPIO, utils
from fpioa_manager import fm
from hiwonder import hw_uart
import time
import binascii


#初始化LCD(initialize LCD)
lcd.init()
#以下是初始化传感器(initialize sensors)
sensor.reset()
sensor.set_pixformat(sensor.RGB565)
sensor.set_framesize(sensor.QVGA)
sensor.skip_frames(time = 100)

#帧率时钟(frame rate clock)
clock = time.clock()


# 创建一个64x64的图像对象，设置不拷贝到帧缓存(create a 64x64 image object without copying it to the frame buffer)
feature_img = image.Image(size=(64,64), copy_to_fb=False)
feature_img.pix_to_ai()

# 人脸图片的大小(the size of the face image)
FACE_PIC_SIZE = 64

# 人脸关键点坐标(the coordinates of the ficial keypoints)
dst_point =[(int(38.2946 * FACE_PIC_SIZE / 112), int(51.6963 * FACE_PIC_SIZE / 112)),
            (int(73.5318 * FACE_PIC_SIZE / 112), int(51.5014 * FACE_PIC_SIZE / 112)),
            (int(56.0252 * FACE_PIC_SIZE / 112), int(71.7366 * FACE_PIC_SIZE / 112)),
            (int(41.5493 * FACE_PIC_SIZE / 112), int(92.3655 * FACE_PIC_SIZE / 112)),
            (int(70.7299 * FACE_PIC_SIZE / 112), int(92.2041 * FACE_PIC_SIZE / 112)) ]

# YOLO模型的锚点和参数初始化(initialize YOLO model anchor points and parameters)
anchor = (0.1075, 0.126875, 0.126875, 0.175, 0.1465625, 0.2246875, 0.1953125, 0.25375, 0.2440625, 0.351875, 0.341875, 0.4721875, 0.5078125, 0.6696875, 0.8984375, 1.099687, 2.129062, 2.425937)
kpu = KPU()
kpu.load_kmodel("/sd/KPU/yolo_face_detect/face_detect_320x240.kmodel")
kpu.init_yolo2(anchor, anchor_num=9, img_w=320, img_h=240, net_w=320 , net_h=240 ,layer_w=10 ,layer_h=8, threshold=0.7, nms_value=0.2, classes=1)

# 加载人脸识别模型(load face recognition model)
ld5_kpu = KPU()
print("ready load model")
ld5_kpu.load_kmodel("/sd/KPU/face_recognization/ld5.kmodel")

# 加载特征提取模型(load feature extracting model)
fea_kpu = KPU()
print("ready load model")
fea_kpu.load_kmodel("/sd/KPU/face_recognization/feature_extraction.kmodel")

# 标记是否开始人脸识别(mark the start of the face recognition)
start_processing = False

# 按键防抖时间(debouncing time for a button press)
BOUNCE_PROTECTION = 50

# 硬件引脚(hardware pins)
key1_pin = 26
key2_pin = 47

# 注册启动按键(register start button)
fm.register(key1_pin, fm.fpioa.GPIOHS0)
key_gpio = GPIO(GPIO.GPIOHS0, GPIO.IN)
def set_key_state(*_):
    global start_processing
    start_processing = True
    time.sleep_ms(BOUNCE_PROTECTION)
key_gpio.irq(set_key_state, GPIO.IRQ_RISING, GPIO.WAKEUP_NOT_SUPPORT)

# 保存已识别人脸特征(save the recognized face feature)
record_ftrs = []

# 人脸识别阈值(face recognition threshold)
THRESHOLD = 80.5

# 识别标志(recognition flag)
recog_flag = False

def extend_box(x, y, w, h, scale):
    # 计算扩展后的检测框坐标和尺寸(calculate the expanded coordinates and dimensions of the detection box)
    x1_t = x - scale*w
    x2_t = x + w + scale*w
    y1_t = y - scale*h
    y2_t = y + h + scale*h
    # 限制坐标范围(limit coordinate range)
    x1 = int(x1_t) if x1_t>1 else 1
    x2 = int(x2_t) if x2_t<320 else 319
    y1 = int(y1_t) if y1_t>1 else 1
    y2 = int(y2_t) if y2_t<240 else 239
    # 扩展后的裁剪图像宽度(the expanded width of the cropped image)
    cut_img_w = x2-x1+1
    # 扩展后的裁剪图像高度(the expanded height of the cropped image)
    cut_img_h = y2-y1+1
    # 返回扩展后的检测框信息(return the information for the expanded detection box)
    return x1, y1, cut_img_w, cut_img_h


try:

    #loop
    while True:
        # 手动触发垃圾回收(manually trigger waste collection)
        gc.collect()
        # print("mem free:",gc.mem_free())
        # print("heap free:",utils.heap_free())
        #从相机获取图像(obtain image from the camera)
        clock.tick()
        # 获取摄像头拍摄的图像(obtain the captured image from the camera)
        img = sensor.snapshot()
        # 使用KPU模型运行人脸检测(use the KPU model to run the face detection)
        kpu.run_with_output(img)
        # 获取人脸检测结果(obtain face detection result)
        dect = kpu.regionlayer_yolo2()
        # 获取帧率(obtain frame rate)
        fps = clock.fps()

        # 如果有检测到人脸(if a face is detected)
        if len(dect) > 0:
            # 遍历(iterate)
            for l in dect :
                # 扩展检测框(expand detection box)
                x1, y1, cut_img_w, cut_img_h= extend_box(l[0], l[1], l[2], l[3], scale=0)
                # 裁剪人脸区域(crop face region)
                face_cut = img.cut(x1, y1, cut_img_w, cut_img_h)
                # 缩放为128x128(scale to 128x128)
                face_cut_128 = face_cut.resize(128, 128)
                # 转换为AI数据格式(convert to AI data format)
                face_cut_128.pix_to_ai()
                # 使用人脸识别模型获取特征点(use face recognition model to obtain keypoints)
                out = ld5_kpu.run_with_output(face_cut_128, getlist=True)
                face_key_point = []
                for j in range(5):
                    x = int(KPU.sigmoid(out[2 * j])*cut_img_w + x1)
                    y = int(KPU.sigmoid(out[2 * j + 1])*cut_img_h + y1)
                    face_key_point.append((x,y))
                # 获取仿射变换矩阵(obtain the affine transformation matrix)
                T = image.get_affine_transform(face_key_point, dst_point)
                # 人脸对齐变换(face alignment transformation)
                image.warp_affine_ai(img, feature_img, T)
                # 使用特征提取模型提取特征(Extract features using a feature extraction model)
                feature = fea_kpu.run_with_output(feature_img, get_feature = True)
                del face_key_point
                scores = []
                for j in range(len(record_ftrs)):
                    score = kpu.feature_compare(record_ftrs[j], feature)
                    scores.append(score)
                if len(scores):
                    max_score = max(scores)
                    index = scores.index(max_score)
                    if max_score > THRESHOLD: # 判断是否超过阈值(determining whether it surpasses the threshold)
                        img.draw_string(0, 195, "persion:%d,score:%2.1f" %(index, max_score), color=(0, 255, 0), scale=2)
                        recog_flag = True
                        # if index == 0:
                        #     img.draw_string(0, 195, "zhangsan, score:%2.1f" %(max_score), color=(0, 255, 0), scale=2)
                        # elif index == 1:
                        #     img.draw_string(0, 195, "lisi, score:%2.1f" %(max_score), color=(0, 255, 0), scale=2)
                        # elif index == 2:
                        #     img.draw_string(0, 195, "wangwu, score:%2.1f" %(max_score), color=(0, 255, 0), scale=2)
                        # elif index == 3:
                        #     img.draw_string(0, 195, "zhaoliu, score:%2.1f" %(max_score), color=(0, 255, 0), scale=2)
                        # else:
                        #     img.draw_string(0, 195, "persion:%d,score:%2.1f" %(index, max_score), color=(0, 255, 0), scale=2)
                    else:
                        img.draw_string(0, 195, "unregistered,score:%2.1f" %(max_score), color=(255, 0, 0), scale=2)
                del scores

                if start_processing: # 标志位为真时进行人脸注册(If the flag is ture, perform facial registration)
                    record_ftrs.append(feature)
                    print("record_ftrs:%d" % len(record_ftrs))
                    start_processing = False

                # 如果进行了人脸识别(if the face recognition is performed)
                # 根据检测结果绘制不同颜色的矩形和文字标注，并将消息赋值(Draw rectangles with different colors and annotate text based on the detection results, and assign values to the message)
                if recog_flag: # 识别到(if the target is recognized)
                    img.draw_rectangle(l[0],l[1],l[2],l[3], color=(0, 255, 0))
                    recog_flag = False
                    msg_ = "Y"
                else:
                    img.draw_rectangle(l[0],l[1],l[2],l[3], color=(255, 255, 255))
                    msg_ = "N" # 未识别到(if the target is not recognized)
                del (face_cut_128)
                del (face_cut)

        # 绘制帧率信息(draw frame rate information)
        img.draw_string(0, 0, "%2.1ffps" %(fps), color=(0, 60, 255), scale=2.0)
        # 绘制提示信息(draw prompt message)
        img.draw_string(0, 215, "press key1 to regist face", color=(255, 100, 0), scale=2.0)
        lcd.display(img) # 显示图像(display image)

#捕获错误并处理(capture errors and handle them)
except Exception as e:
    raise e
finally:
    #若出现错误，则释放 KPU 资源(If there is an error, release KPU resource)
    kpu.deinit()
    ld5_kpu.deinit()
    fea_kpu.deinit()
