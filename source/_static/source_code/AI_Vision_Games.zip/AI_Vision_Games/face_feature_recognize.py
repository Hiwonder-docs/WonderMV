'''
@file:    face_feature_recognize.py
@company: Hiwonder
@author:  CuZn
@date:    2023-08-22
@description: 人脸特征识别(face feature recognition)
'''


import sensor  #导入相机模块(import vision module)
import image   #导入图像处理模块(import image processing module)
import time    #导入时间模块(import time module)
import lcd     #导入 LCD 屏幕模块(import LCD screen module)
#加载KPU模块(load KPU module)
from maix import KPU


#初始化LCD(initialize LCD)
lcd.init()
#以下是初始化传感器(initialize sensors)
sensor.reset()
sensor.set_pixformat(sensor.RGB565)
sensor.set_framesize(sensor.QVGA)
sensor.skip_frames(time = 100)
#帧率时钟(frame rate clock)
clock = time.clock()

#创建锚框的尺寸列表，用于目标检测(create a list of anchor box sizes for target detection)
anchor = (0.1075, 0.126875, 0.126875, 0.175, 0.1465625,
 0.2246875, 0.1953125, 0.25375, 0.2440625, 0.351875, 0.341875, 
 0.4721875, 0.5078125, 0.6696875, 0.8984375, 1.099687, 2.129062, 2.425937)

#创建 KPU 模型对象(create KPU model object)
kpu = KPU()

#加载 YOLO 目标检测模型文件（.kmodel 格式）(load YOLO target detection model file in .kmodel format)
kpu.load_kmodel("/sd/KPU/yolo_face_detect/face_detect_320x240.kmodel")

#使用 init_yolo2 初始化 YOLO 模型参数(initialize YOLO model parameters using init_yolo2)
#anchor: 锚框的尺寸列表，用于目标检测(list of anchor box sizes for object detection)
#anchor_num: 锚框的数量(number of anchor boxes)
#img_w, img_h: 输入图像的宽度和高度(width and height of the input image)
#net_w, net_h: 模型输入的宽度和高度(width and height of the model input)
#layer_w, layer_h: 模型最终层的宽度和高度(width and height of the final layer of the model)
#threshold: 检测目标的置信度阈值(confidence threshold for detecting objects)
#nms_value: 非最大抑制的 IOU 阈值(IOU threshold for non-maximum suppression)
#classes: 目标类别数量(number of target classes)
kpu.init_yolo2(anchor, anchor_num=9, img_w=320, img_h=240, net_w=320 , net_h=240 ,layer_w=10 ,layer_h=8, threshold=0.7, nms_value=0.2, classes=1)


lm68_kpu = KPU()
print("ready load model")
#加载人脸特征检测模型文件（.kmodel 格式）用于进行人脸检测和 68 个关键点的检测(load the facial feature detection model file (.kmodel format) for performing face detection and detection of 68 facial keypoints)
lm68_kpu.load_kmodel("/sd/KPU/face_detect_with_68landmark/landmark68.kmodel")


def extend_box(x, y, w, h, scale):
    #计算扩展后的框的左上角和右下角坐标(calculate the coordinates of the top-left and bottom-right corners of the expanded box)
    x1_t = x - scale*w
    x2_t = x + w + scale*w
    y1_t = y - scale*h
    y2_t = y + h + scale*h
    #将坐标限制在图像范围内(limit the coordinate within the range of the image)
    x1 = int(x1_t) if x1_t>1 else 1
    x2 = int(x2_t) if x2_t<320 else 319
    y1 = int(y1_t) if y1_t>1 else 1
    y2 = int(y2_t) if y2_t<240 else 239
    #计算扩展后的框的宽度和高度(calculate the width and height of the expanded box)
    cut_img_w = x2-x1+1
    cut_img_h = y2-y1+1
    #返回扩展后的框的左上角坐标、宽度和高度(return the coordinates of the top-left corner, width, and height of the expanded box)
    return x1, y1, cut_img_w, cut_img_h


try:
    '''
    loop逻辑：(loop logic)
        1 从摄像头捕获图像(capture an image from the camera)
        2 使用KPU模型运行人脸检测，获取检测到的人脸框(perform face detection using the KPU model to obtain detected face bounding boxes)
        3 遍历检测到的人脸框，扩展框并截取人脸图像(Iterate through the detected face boxes, expanding boxes, and cropping the face images)
        4 将人脸图像缩放到128x128像素，并使用KPU模型运行关键点检测(Scale the face images to 128x128 pixels and run keypoint detection using the KPU model)
        5 绘制检测到的关键点(draw the detected keypoints)
        6 在图像上显示帧率(display the frame rate on the image)
        7 在LCD上显示处理后的图像(display the processed image on the LCD)
    '''
    while True:
        clock.tick()  #计算每秒帧率(calculate the frame rate per second)
        img = sensor.snapshot()  #捕获摄像头图像(capture image from the camera)
        kpu.run_with_output(img) #使用KPU模型运行人脸检测(use KPU model to perform face detection)
        dect = kpu.regionlayer_yolo2()  #获取检测到的人脸框列表(obtain the list of detected face bounding boxes)
        fps = clock.fps()  #获取帧率(obtain frame rate)

        if len(dect) > 0:
            #遍历检测到的人脸框(iterate through the detected face bounding boxes)
            for l in dect:
                #扩展人脸框并截取人脸图像(expand the face box and crop the face image)
                x1, y1, cut_img_w, cut_img_h = extend_box(l[0], l[1], l[2], l[3], scale=0.08)
                face_cut = img.cut(x1, y1, cut_img_w, cut_img_h)
                #将人脸图像缩放到128x128像素(scale the face image to 128x128 pixels)
                face_cut_128 = face_cut.resize(128, 128)
                face_cut_128.pix_to_ai()
                #使用KPU模型运行关键点检测(run keypoint detection using the KPU model)
                out = lm68_kpu.run_with_output(face_cut_128, getlist=True)
                #绘制检测到的关键点(draw the detected keypoints)
                for j in range(68):
                    x = int(KPU.sigmoid(out[2 * j]) * cut_img_w + x1)
                    y = int(KPU.sigmoid(out[2 * j + 1]) * cut_img_h + y1)
                    img.draw_circle(x, y, 2, color=(0, 0, 255), fill=True)

                del face_cut_128
                del face_cut

        #在图像上显示帧率(display the frame rate on the image)
        img.draw_string(0, 0, "%2.1ffps" % fps, color=(0, 60, 255), scale=2.0)
        lcd.display(img)  #在LCD上显示图像(display the image on the LCD)

#捕获错误并处理(capture and process errors)
except Exception as e:
    raise e
finally:
    #若出现错误，则释放 KPU 资源(If there is an error, release the KPU resource)
    kpu.deinit()
    lm68_kpu.deinit()








