'''
@file:    facemask_recognition.py
@company: Hiwonder
@author:  CuZn
@date:    2023-08-24
@description: 物体检测(object detection)
'''


import sensor  #导入相机模块(import vision module)
import image   #导入图像处理模块(import image processing module)
import time    #导入时间模块(import time module)
import lcd     #导入 LCD 屏幕模块(import LCD screen module)
#加载KPU模块(load KPU module)
from maix import KPU


#初始化LCD(initialize LCD)
lcd.init()
#以下是初始化传感器(initialize sensors)
sensor.reset()
sensor.set_pixformat(sensor.RGB565)
sensor.set_framesize(sensor.QVGA)
sensor.skip_frames(time = 100)
#帧率时钟(frame rate clock)
clock = time.clock()

#物体名称(object name)
obj_name = ("aeroplane", "bicycle", "bird", "boat", "bottle", "bus", "car", "cat", "chair", "cow", "diningtable", "dog", "horse", "motorbike", "person", "potted", "sheep", "sofa", "train", "tvmonitor")

#创建图像对象(create image object)
img_obj = image.Image(size=(320,256))

#创建锚框的尺寸列表，用于目标检测(create a list of anchor box sizes for target detection)
anchor = (1.3221, 1.73145, 3.19275, 4.00944, 5.05587, 8.09892, 9.47112, 4.84053, 11.2364, 10.0071)

#创建 KPU 模型对象(create KPU model object)
kpu = KPU()

#加载物体检测模型文件（.kmodel 格式）(load object detection model file in .kmodel format)
kpu.load_kmodel("/sd/KPU/voc20_object_detect/voc20_detect.kmodel")

#使用 init_yolo2 初始化 YOLO 模型参数(initialize YOLO model parameters using init_yolo2)
#anchor: 锚框的尺寸列表，用于目标检测(list of anchor box sizes for object detection)
#anchor_num: 锚框的数量(number of anchor boxes)
#img_w, img_h: 输入图像的宽度和高度(width and height of the input image)
#net_w, net_h: 模型输入的宽度和高度(width and height of the model input)
#layer_w, layer_h: 模型最终层的宽度和高度(width and height of the final layer of the model)
#threshold: 检测目标的置信度阈值(confidence threshold for detecting objects)
#nms_value: 非最大抑制的 IOU 阈值(IOU threshold for non-maximum suppression)
#classes: 目标类别数量(number of target classes)
kpu.init_yolo2(anchor, anchor_num=5, img_w=320, img_h=240, net_w=320 , net_h=256 ,layer_w=10 ,layer_h=8, threshold=0.7, nms_value=0.2, classes=20)


try:
    #loop
    while True:
        #计算每秒帧率(calculate the frame rate per second)
        clock.tick()
        #捕获摄像头图像(capture image from the camera)
        img = sensor.snapshot()
        #将图像复制到图像对象并转换像素为KPU格式(transfer the image to an image object and convert the pixels to KPU format)
        img_obj.draw_image(img, 0,0)
        img_obj.pix_to_ai()
        #运行KPU模型，获取检测结果(run KPU model to obtain the detection result)
        kpu.run_with_output(img_obj)
        dect = kpu.regionlayer_yolo2()
        #计算帧率(calculate frame rate)
        fps = clock.fps()
        #如果检测到目标(if the target is detected)
        if len(dect) > 0:
            print("dect:",dect)
            #遍历(iterate through)
            for l in dect :
                #绘制检测框(draw detection box)
                img.draw_rectangle(l[0],l[1],l[2],l[3], color=(0, 255, 0))
                #绘制检测结果文字(display detection result)
                img.draw_string(l[0],l[1], obj_name[l[4]], color=(0, 255, 0), scale=1.5)
        #绘制帧率信息(draw the frame rate information)
        img.draw_string(0, 0, "%2.1ffps" %(fps), color=(0, 60, 128), scale=2.0)
        #在LCD上显示图像(display the image on the LCD)
        lcd.display(img)



#捕获错误并处理(capture and process errors)
except Exception as e:
    raise e
finally:
    #若出现错误，则释放 KPU 资源(If there is an error, release the KPU resource)
    kpu.deinit()
