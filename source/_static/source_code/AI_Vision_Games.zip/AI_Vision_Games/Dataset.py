# Untitled - By: Administrator  

import image

#载入传感器控制模块(load sensor control module)
import sensor
#载入LCD控制模块(load LCD control module)
import lcd
#载入时间控制模块(load time control module)
import time
import uos
from hiwonder import hw_key , fill_light

#用于判断文件夹是否存在，如不存在则创建该文件夹(It is used to check whether the folder exits. If not, create it)
def create_directory(_path):
    folders = _path.split('/')[1:]
    path = ''
    for folder in folders:
        path += '/' + folder
        try:
            uos.mkdir(path)
        except OSError:
            continue

sensor.reset()
sensor.set_pixformat(sensor.RGB565)
sensor.set_framesize(sensor.QVGA)
sensor.skip_frames(time = 2000)

clock = time.clock()

lcd.init(type=1, freq=15000000, color=lcd.BLACK, invert = 0, lcd_type = 0)

key = hw_key()
#创建补光灯控制对象(create fill light control object)
f_led = fill_light()

#文件夹名称(folder name)
current_folder = 1
#图片名称(image name)
image_count = 1

led_count = 0
onoff = 0

while(True):
    clock.tick()
    img = sensor.snapshot()
    img_ds = img
    #在图片上显示当前的文件以及图片的数量(display the number of the current files and images on the screen)
    img_ds.draw_string(0, 0, "%d/%d" %(current_folder,image_count), color=(0, 255, 0), scale=1.5)
    lcd.display(img_ds)
    if key.key_scan(1) == 1:#通过按K1按键将图片保存于设置的路径中(press K1 button to save the image into the set path)
        if current_folder == 1:
            create_directory("/sd/image/1/")#判断文件夹是否存在(check if the folder exits)
            filename = "/sd/image/1/c{}.jpg".format(image_count) #将图片保存在该路径下(save the image under the path)
        elif current_folder == 2:
            create_directory("/sd/image/2/")
            filename = "/sd/image/2/c{}.jpg".format(image_count)
        elif current_folder == 3:
            create_directory("/sd/image/3/")
            filename = "/sd/image/3/c{}.jpg".format(image_count)
        #elif current_folder == 4:
            #create_directory("/sd/image/4/")
            #filename = "/sd/image/4/c{}.jpg".format(image_count)
        #elif current_folder == 5:
            #create_directory("/sd/image/5/")
            #filename = "/sd/image/5/c{}.jpg".format(image_count)
        #elif current_folder == 6:
            #filename = "/sd/image/6/c{}.jpg".format(image_count)
        #elif current_folder == 7:
            #filename = "/sd/image/7/c{}.jpg".format(image_count)
        #elif current_folder == 8:
            #filename = "/sd/image/8/c{}.jpg".format(image_count)
        #elif current_folder == 9:
            #filename = "/sd/image/9/c{}.jpg".format(image_count)
        #elif current_folder == 10:
            #filename = "/sd/image/10/c{}.jpg".format(image_count)
        #elif current_folder == 11:
            #filename = "/sd/image/11/c{}.jpg".format(image_count)
        #elif current_folder == 12:
            #filename = "/sd/image/12/c{}.jpg".format(image_count)

        img.save(filename)#保存图片于该路径下(save the image under the path)
        image_count += 1
        print("key1")
        time.sleep_ms(300)
    if key.key_scan(2) == 1:
        led_count += 1
        if led_count > 4:
            if onoff == 0:
                f_led.fill_onoff(0) #补光灯关(turn on fill light)
                onoff = 1
            else:
                f_led.fill_onoff(1) #补光灯开(turn off fill light)
                onoff = 0
        current_folder += 1
        print("key2")
        if current_folder > 3: #用于设置文件夹数量(used for setting the number of the folders)
            current_folder = 1
        time.sleep_ms(500)
    else:
        led_count = 0
