'''
@file:    apriltags_recognition.py
@company: Hiwonder
@author:  CuZn
@date:    2023-08-21
@description: 机器码识别(AprilTag recognition)
'''


import sensor       #导入相机模块，用于图像采集(import the camera module for image acquisition)
import image        #导入图像处理模块，用于图像处理操作(import the image processing module for image processing)
import time         #导入时间模块，用于时间相关操作(import the time module for time-related operations)
import math         #导入数学模块，用于数学计算(import the math module for mathematical calculations)
import lcd          #导入LCD模块，用于图像显示(import the LCD module for image display)


#初始化LCD(initialize LCD)
lcd.init()
#以下是初始化传感器(initialize sensors)
sensor.reset()
sensor.set_pixformat(sensor.RGB565)
sensor.set_framesize(sensor.QQVGA)
#sensor.set_framesize(sensor.QVGA)
sensor.skip_frames(time = 100)
sensor.set_auto_gain(False)
sensor.set_auto_whitebal(False)
#帧率时钟(frame rate clock)
clock = time.clock()


#设置机器码掩码(set the AprilTag mask)
tag_families = 0
tag_families |= image.TAG16H5   # comment out to disable this family
tag_families |= image.TAG25H7   # comment out to disable this family
tag_families |= image.TAG25H9   # comment out to disable this family
tag_families |= image.TAG36H10  # comment out to disable this family
tag_families |= image.TAG36H11  # comment out to disable this family (default family)
tag_families |= image.ARTOOLKIT # comment out to disable this family


#机器码转换成字符串(convert the AprilTag to string)
def family_str(tag):
    if(tag.family() == image.TAG16H5):
        return "TAG16H5"
    if(tag.family() == image.TAG25H7):
        return "TAG25H7"
    if(tag.family() == image.TAG25H9):
        return "TAG25H9"
    if(tag.family() == image.TAG36H10):
        return "TAG36H10"
    if(tag.family() == image.TAG36H11):
        return "TAG36H11"
    if(tag.family() == image.ARTOOLKIT):
        return "ARTOOLKIT"


#loop
while(True):
    #用于计算帧率的函数，这里表示开始计时(The function is used for calculating frame rate, indicating the start of timing)
    clock.tick()
    #获取传感器图像(obtain sensor image)
    img = sensor.snapshot()

    #从图像中识别机器码(try to recognize the AprilTag from the image)
    for code in img.find_apriltags(families=tag_families):
        #绘制矩形和十字标记(draw a rectangle and cross)
        img.draw_rectangle(code.rect(), color = (255, 0, 0))
        img.draw_cross(code.cx(), code.cy(), color = (0, 255, 0))
        ##打印机器码 名称，ID，角度(print the name, ID, and angle of the AprilTag)
        print("%s, ID %d, rotation %f (degrees)" % (family_str(code),
                                                        code.id(),
                                                        (180 * code.rotation()) / math.pi) )

    #显示在LCD上(display the result on the LCD)
    lcd.display(img)
    #打印帧率(print the frame rate)
    print(clock.fps())
