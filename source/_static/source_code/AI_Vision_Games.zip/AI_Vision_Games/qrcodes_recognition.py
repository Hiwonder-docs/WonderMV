'''
@file:    qrcodes_recognition.py
@company: Hiwonder
@author:  CuZn
@date:    2023-08-21
@description: 二维码识别(QR code recognition)
'''


import sensor
import image
import time
import lcd


#初始化LCD(initialize LCD)
lcd.init()
#以下是初始化传感器(initialize sensors)
sensor.reset()
sensor.set_pixformat(sensor.RGB565)
sensor.set_framesize(sensor.QVGA)
sensor.skip_frames(time = 100)
#帧率时钟(frame rate clock)
clock = time.clock()


#loop
while(True):
    #用于计算帧率的函数，这里表示开始计时(The function is used for calculating frame rate, indicating the start of timing)
    clock.tick()
    #获取传感器图像(obtain sensor image)
    img = sensor.snapshot()
    qr_code = img.find_qrcodes()

    # 如果识别到二维码，处理识别结果(If the QR code is recognized, process the recognition result)
    if qr_code:
        for code in qr_code:
            img.draw_rectangle(code.rect(), color=(0, 255, 0),thickness=3)
            img.draw_string(code.x(), code.y(), code.payload(), color=(255, 255, 0),scale=2)
    #在LCD上显示处理后的图像(display the processed image on the LCD)
    lcd.display(img)
    #打印帧率(print the frame rate)
    print(clock.fps())







