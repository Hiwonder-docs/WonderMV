'''
@file:    facemask_recognition.py
@company: Hiwonder
@author:  CuZn
@date:    2023-08-22
@description: 口罩识别(mask recognition)
'''


import sensor  #导入相机模块(import vision module)
import image   #导入图像处理模块(import image processing module)
import time    #导入时间模块(import time module)
import lcd     #导入 LCD 屏幕模块(import LCD screen module)
#加载KPU模块(load KPU module)
from maix import KPU


#初始化LCD(initialize LCD)
lcd.init()
#以下是初始化传感器(initialize sensors)
sensor.reset()
sensor.set_pixformat(sensor.RGB565)
sensor.set_framesize(sensor.QVGA)
sensor.skip_frames(time = 100)
#帧率时钟(frame rate clock)
clock = time.clock()

#创建锚框的尺寸列表，用于目标检测(create a list of anchor box sizes for target detection)
anchor = (0.156250, 0.222548, 0.361328, 0.489583, 0.781250, 0.983133, 1.621094, 1.964286, 3.574219, 3.94000)

#创建图像对象(create image object)
img_obj = image.Image(size=(320,256), copy_to_fb=False)

#创建 KPU 模型对象(create KPU model object)
kpu = KPU()

#加载口罩检测模型文件（.kmodel 格式）(load mask detection model file in .kmodel format)
kpu.load_kmodel("/sd/KPU/face_mask_detect/detect_5.kmodel")

#使用 init_yolo2 初始化 YOLO 模型参数(initialize YOLO model parameters using init_yolo2)
#anchor: 锚框的尺寸列表，用于目标检测(list of anchor box sizes for object detection)
#anchor_num: 锚框的数量(number of anchor boxes)
#img_w, img_h: 输入图像的宽度和高度(width and height of the input image)
#net_w, net_h: 模型输入的宽度和高度(width and height of the model input)
#layer_w, layer_h: 模型最终层的宽度和高度(width and height of the final layer of the model)
#threshold: 检测目标的置信度阈值(confidence threshold for detecting objects)
#nms_value: 非最大抑制的 IOU 阈值(IOU threshold for non-maximum suppression)
#classes: 目标类别数量(number of target classes)
kpu.init_yolo2(anchor, anchor_num=5, img_w=320, img_h=240, net_w=320 , net_h=256 ,layer_w=10 ,layer_h=8, threshold=0.7, nms_value=0.4, classes=2)


try:
    #loop
    while True:
        #计算每秒帧率(calculate the frame rate per second)
        clock.tick()
        #捕获摄像头图像(obtain image from camera)
        img = sensor.snapshot()
        #将图像复制到图像对象并转换像素为KPU格式(copy the image to an image object and convert the pixels to KPU format)
        img_obj.draw_image(img, 0, 0)
        img_obj.pix_to_ai()
        #运行KPU模型，获取检测结果(Run the KPU model and obtain detection result)
        kpu.run_with_output(img_obj)
        dect = kpu.regionlayer_yolo2()
        fps = clock.fps()
        if len(dect) > 0:
            print("dect:", dect)
            for l in dect:
                #根据检测结果判断是否佩戴口罩，绘制不同颜色的矩形和文字标注(Check the presence of a mask on the face based on the detection results, and draw rectangles and text annotations in different colors)

# Iterate through the detection results
for detection in detections:)
                if l[4]:
                    img.draw_rectangle(l[0], l[1], l[2], l[3], color=(0, 255, 0))
                    img.draw_string(l[0], l[1] - 24, "with mask", color=(0, 255, 0), scale=2)
                else:
                    img.draw_rectangle(l[0], l[1], l[2], l[3], color=(255, 0, 0))
                    img.draw_string(l[0], l[1] - 24, "without mask", color=(255, 0, 0), scale=2)
        #在图像上绘制帧率信息(display the frame rate on the image)
        img.draw_string(0, 0, "%2.1ffps" % (fps), color=(0, 60, 128), scale=2.0)
        #在LCD上显示图像(display the image on the LCD)
        lcd.display(img)



#捕获错误并处理(capture and process errors)
except Exception as e:
    raise e
finally:
    #若出现错误，则释放 KPU 资源(If there is an error, release the KPU resource)
    kpu.deinit()
