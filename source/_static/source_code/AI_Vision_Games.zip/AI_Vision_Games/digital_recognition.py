'''
@file:    digital_recognition.py
@company: Hiwonder
@author:  CuZn
@date:    2023-08-24
@description: 数字检测(number detection)
'''


import sensor  #导入相机模块(import vision module)
import image   #导入图像处理模块(import image processing module)
import time    #导入时间模块(import time module)
import lcd     #导入 LCD 屏幕模块(import LCD screen module)
#加载KPU模块(load KPU module)
from maix import KPU
#导入回收模块(import gc module)
import gc


#初始化LCD(initialize LCD)
lcd.init()
#以下是初始化传感器(initialize LCD)
sensor.reset()
sensor.set_pixformat(sensor.RGB565)
sensor.set_framesize(sensor.QVGA)
sensor.set_windowing((224, 224))
sensor.skip_frames(time = 100)
#帧率时钟(frame rate clock)
clock = time.clock()


#创建 KPU 模型对象(create KPU model object)
kpu = KPU()
#加载检测模型文件（.kmodel 格式）(load detection model file in .kmodel format)
kpu.load_kmodel("/sd/KPU/mnist/uint8_mnist_cnn_model.kmodel")


try:

    #loop
    while True:
        # 进行垃圾回收以释放内存(perform waste collection to free up memory)
        gc.collect()
        # 从摄像头传感器捕获图像(capture an image from the vision module)
        img = sensor.snapshot()
        # 将图像转换为灰度格式(convert the image to grayscale format)
        img_mnist1=img.to_grayscale(1)
        # 将图像调整大小为特定尺寸（112x112）(adjust the image to a specific size (112x112))
        img_mnist2=img_mnist1.resize(112,112)
        # 反转图像的颜色(invert the colors of the image)
        img_mnist2.invert()
        # 对图像应用对比度拉伸以增强图像特征(apply contrast stretching to the image to enhance image features)
        img_mnist2.strech_char(1)
        # 将处理后的图像转换为AI格式(convert the processed image to AI format)
        img_mnist2.pix_to_ai()
        # 在处理后的图像上运行AI模型并获取输出列表(run the AI model on the processed image and obtain the output list)
        out = kpu.run_with_output(img_mnist2, getlist=True)
        # 在输出列表中找到最大值及其索引(find the maximum value and its index in the output list)
        max_mnist = max(out)
        index_mnist = out.index(max_mnist)
        # 对最大值应用Sigmoid函数以获得置信度分数(apply the Sigmoid function to the maximum value to obtain a confidence score)
        score = KPU.sigmoid(max_mnist)

        # 检查识别出的数字是否为1或5(check if the recognized number is 1 or 5)
        if index_mnist == 1:
            if score > 0.999:
                display_str = "num: %d" % index_mnist
                print(display_str, score)
                img.draw_string(4,3,display_str,color=(0,0,0),scale=2)
        elif index_mnist == 5:
            if score > 0.999:
                display_str = "num: %d" % index_mnist
                print(display_str, score)
                img.draw_string(4,3,display_str,color=(0,0,0),scale=2)
        else:
            display_str = "num: %d" % index_mnist
            print(display_str, score)
            img.draw_string(4,3,display_str,color=(0,0,0),scale=2)

        # 在LCD屏幕上显示图像(display the processed image on the LCD)
        lcd.display(img)



#捕获错误并处理(capture and process errors)
except Exception as e:
    raise e
finally:
    #若出现错误，则释放 KPU 资源(If there is an error, release the KPU resource)
    kpu.deinit()

