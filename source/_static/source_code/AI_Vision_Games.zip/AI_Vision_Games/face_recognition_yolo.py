'''
@file:    face_recognition_yolo.py
@company: Hiwonder
@author:  CuZn
@date:    2023-08-22
@description: 人脸识别(face recognition)
'''


import sensor  #导入相机模块(import vision module)
import image   #导入图像处理模块(import image processing module)
import time    #导入时间模块(import time module)
import lcd     #导入 LCD 屏幕模块(import LCD screen module)
#加载KPU模块(load KPU module)
from maix import KPU


#初始化LCD(initialize LCD)
lcd.init()
#以下是初始化传感器(initialize LCD)
sensor.reset()
sensor.set_pixformat(sensor.RGB565)
sensor.set_framesize(sensor.QVGA)
sensor.skip_frames(time = 100)
#帧率时钟(frame rate clock)
clock = time.clock()

#创建图像对象(create image object)
img_obj = image.Image(size=(320,256))

#创建锚框的尺寸列表，用于目标检测(create a list of anchor box sizes for target detection)
anchor = (0.893, 1.463, 0.245, 0.389, 1.55, 2.58, 0.375, 0.594, 3.099, 5.038, 0.057, 0.090, 0.567, 0.904, 0.101, 0.160, 0.159, 0.255)


#创建 KPU 模型对象(create KPU model object)
kpu = KPU()

#加载 YOLO 目标检测模型文件（.kmodel 格式）(load YOLO target detection model file in .kmodel format)
kpu.load_kmodel("/sd/KPU/yolo_face_detect/yolo_face_detect.kmodel")

#使用 init_yolo2 初始化 YOLO 模型参数(initialize YOLO model parameters using init_yolo2)
#anchor: 锚框的尺寸列表，用于目标检测(list of anchor box sizes for object detection)
#anchor_num: 锚框的数量(number of anchor boxes)
#img_w, img_h: 输入图像的宽度和高度(width and height of the input image)
#net_w, net_h: 模型输入的宽度和高度(width and height of the model input)
#layer_w, layer_h: 模型最终层的宽度和高度(width and height of the final layer of the model)
#threshold: 检测目标的置信度阈值(confidence threshold for detecting objects)
#nms_value: 非最大抑制的 IOU 阈值(IOU threshold for non-maximum suppression)
#classes: 目标类别数量(number of target classes)
kpu.init_yolo2(anchor, anchor_num=9, img_w=320, img_h=240, net_w=320, net_h=256, layer_w=10, layer_h=8, threshold=0.75, nms_value=0.3, classes=1)



try:
    #loop
    while True:
        clock.tick()  #计算每秒帧率(calculate the frame rate per second)
        img = sensor.snapshot()  #从相机获取图像(obtain image from camera)
        #将图像数据复制到 img_obj 对象中，以便传递给 KPU 运行(copy the image data to the img_obj object for passing it to the KPU for execution)
        img_obj.draw_image(img, 0, 0)
        img_obj.pix_to_ai()
        #使用 KPU 运行目标检测模型(use KPU to run the target detection model)
        kpu.run_with_output(img_obj)
        #获取检测结果(obtain detection result)
        dect = kpu.regionlayer_yolo2()
        #计算帧率(calculate frame rate)
        fps = clock.fps()
        #如果检测到目标(if the target is detected)
        if len(dect) > 0:
            for l in dect:
                #在图像上绘制检测到的目标框(draw the detected target box on the image)
                img.draw_rectangle(l[0], l[1], l[2], l[3], color=(0, 255, 0))
        #在图像上显示帧率(display the frame rate on the image)
        img.draw_string(0, 0, "%2.1ffps" % (fps), color=(100, 150, 255), scale=2.0)
        #在 LCD 上显示处理后的图像(display the processed image on the LCD)
        lcd.display(img)

#捕获错误并处理(capture and process errors)
except Exception as e:
    raise e
finally:
    #若出现错误，则释放 KPU 资源(If there is an error, release the KPU resource)
    kpu.deinit()








