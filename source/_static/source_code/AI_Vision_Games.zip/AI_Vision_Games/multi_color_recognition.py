'''
@file:    color_recognition.py
@company: Hiwonder
@author:  CuZn
@date:    2023-08-21
@description: 学习多种颜色并识别(Learn and recognize multiple colors)
            #第一步：把你想要跟踪的物体放在盒子里的相机前(Step 1: Place the object to be tracked in front of the camera)
            #第二步：确保要跟踪的对象的颜色完全被框包围(Step 2: Ensure that the color of the object to be tracked is completely enclosed within the bounding box)
            #第三步：按下按键，开始学习(Step 3: Press the button to start learning)
'''


import sensor
import image
import time
import lcd

#载入按键控制模块(load button control module)
from hiwonder import hw_key

#初始化LCD(initialize LCD)
lcd.init()
#以下是初始化传感器(initialize sensors)
sensor.reset()
sensor.set_pixformat(sensor.RGB565)
sensor.set_framesize(sensor.QVGA)
sensor.skip_frames(time = 100)
sensor.set_auto_gain(False)
sensor.set_auto_whitebal(False)
#帧率时钟(frame rate clock)
clock = time.clock()

#识别颜色数量(the number of the recognized colors)
color_count = 3

#方框参数(box parameter)
r = [(320//2)-(50//2), (240//2)-(50//2), 50, 50]

#创建按键控制对象(create button control object)
key = hw_key()

state = key.key_scan(1)

print("Start learning ...")
threshold = [[50, 50, 0, 0, 0, 0],[50, 50, 0, 0, 0, 0],[50, 50, 0, 0, 0, 0]] # Middle L, A, B values.

for i in range(color_count):
    bottom_msg = "enter Key1 , learn color {}.".format(i+1)
    #显示图像，等待按键按下(display images and wait for the button to be pressed)
    while (state == 0):
        state = key.key_scan(1)
        img = sensor.snapshot()
        img.draw_rectangle(r)
        img.draw_string(5, 208, bottom_msg, color=(0, 0, 255), scale=2)
        lcd.display(img)

    state = 0

    #第一次赋值(initial assignment)
    img = sensor.snapshot()
    hist = img.get_histogram(roi=r)
    lo = hist.get_percentile(0.01) #获得直方图在1%范围内的CDF(根据需要调整)!(Obtain the CDF of the histogram within a 1% range (adjust as needed)!)
    hi = hist.get_percentile(0.99) #获得直方图在99%范围内的CDF(根据需要调整)!(Obtain the CDF of the histogram within a 99% range (adjust as needed)!)
    threshold[i][0] = (threshold[i][0] + lo.l_value()) // 2
    threshold[i][1] = (threshold[i][1] + hi.l_value()) // 2
    threshold[i][2] = (threshold[i][2] + lo.a_value())
    threshold[i][3] = (threshold[i][3] + hi.a_value())
    threshold[i][4] = (threshold[i][4] + lo.b_value())
    threshold[i][5] = (threshold[i][5] + hi.b_value())



    #连续捕捉了50张图像学习阶段(A continuous capture of 50 images during the learning phase)
    for count in range(50):
        img = sensor.snapshot()
        hist = img.get_histogram(roi=r)
        lo = hist.get_percentile(0.01) #获得直方图在1%范围内的CDF(根据需要调整)!(Obtain the CDF of the histogram within a 1% range (adjust as needed)!)
        hi = hist.get_percentile(0.99) #获得直方图在99%范围内的CDF(根据需要调整)!(Obtain the CDF of the histogram within a 99% range (adjust as needed)!)
        #以百分位数表示的平均值(the average represented in percentiles)
        threshold[i][0] = (threshold[i][0] + lo.l_value()) // 2
        threshold[i][1] = (threshold[i][1] + hi.l_value()) // 2
        threshold[i][2] = (threshold[i][2] + lo.a_value()) // 2
        threshold[i][3] = (threshold[i][3] + hi.a_value()) // 2
        threshold[i][4] = (threshold[i][4] + lo.b_value()) // 2
        threshold[i][5] = (threshold[i][5] + hi.b_value()) // 2
        #将识别区域用方框圈出来(enclose the recognized regions within bounding boxes)
        for blob in img.find_blobs([threshold[i]], pixels_threshold=100, area_threshold=100, merge=True, margin=10):
            img.draw_rectangle(blob.rect())
            img.draw_cross(blob.cx(), blob.cy())
            img.draw_rectangle(r, color=(0,255,0))
        lcd.display(img)


print("Thresholds Learning completed...")

print("Start Color Recognition...")

#loop
while(True):
    #用于计算帧率的函数，这里表示开始计时(The function is used for calculating frame rate, indicating the start of timing)
    clock.tick()
    #从传感器捕获一张图像(capture an image from the sensor)
    img = sensor.snapshot()
    for i in range(color_count):
        #遍历图像中找到的颜色区块(iterate through the color blocks found in the image)
        for blob in img.find_blobs([threshold[i]], pixels_threshold=100, area_threshold=100, merge=True, margin=10):
            #绘制矩形和十字标记(draw a rectangle and cross)
            img.draw_rectangle(blob.rect())
            img.draw_string(blob.x()+5 , blob.y()+5 , "{}".format(i+1) , color=(0, 255, 0), scale=2)
    #显示在LCD上(display on the LCD)
    lcd.display(img)
    #打印帧率(print the frame rate)
    #print(clock.fps())
