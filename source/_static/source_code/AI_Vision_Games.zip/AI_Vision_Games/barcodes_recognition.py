'''
@file:    barcodes_recognition.py
@company: Hiwonder
@author:  CuZn
@date:    2023-08-21
@description: 条形码识别(Barcode recognition)
'''


import sensor
import image
import time
import math
import lcd


#初始化LCD(initialize LCD)
lcd.init()
#以下是初始化传感器(initialize sensors)
sensor.reset()
sensor.set_pixformat(sensor.RGB565)
sensor.set_framesize(sensor.QVGA)
sensor.skip_frames(time = 100)
sensor.set_auto_gain(True)
#sensor.set_auto_whitebal(True , rgb_gain_db = (127.0, 20.0, 250.0)) //设置白平衡(set white balance)
#帧率时钟(frame rate clock)
clock = time.clock()



#loop
while True:
    #用于计算帧率的函数，这里表示开始计时(The function is used for calculating frame rate, indicating the start of timing)
    clock.tick()
    #获取传感器图像(obtain sensor image)
    img = sensor.snapshot()
    #尝试从图像中识别条形码(try to recognize the barcode from the image)
    barcodes = img.find_barcodes()
    #如果识别到条形码，处理识别结果(If the barcode is recognized, process the recognition result)
    if barcodes:
        for code in barcodes:
            img.draw_rectangle(code.rect(), color=(0, 255, 0))
            img.draw_string(code.x(), code.y(),"%s"%(code.payload()), color=(255, 0, 255),scale=2)
            print(code)
    #在LCD上显示处理后的图像(display the processed image on the LCD)
    lcd.display(img)
    #打印帧率(print the frame rate)
    #print(clock.fps())







