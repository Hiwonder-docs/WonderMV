'''
@file:    draw_graph.py
@company: Hiwonder
@author:  CuZn
@date:    2023-08-18
@description: Draw shapes and display on LCD (绘制图形并显示在LCD上)
'''

#Import LCD control module (载入LCD控制模块)
import lcd
#Import image module (载入图像模块)
import image
#Import time control module (载入时间控制模块)
import time

#Initialize LCD (初始化LCD)
lcd.init()

#Create an image object with the same size as the LCD (创建图像对象，大小与LCD一样)
img = image.Image(size=(lcd.width(), lcd.height()))
#Draw a red rectangle the same size as the LCD to use as background (绘制一个红色的矩形，大小与LCD一样，作为背景)
img.draw_rectangle((0, 0, lcd.width(), lcd.height()), fill=True, color=(255, 0, 0))

lcd.display(img) #Display the image (显示图像)
time.sleep(0.5) #Delay for 0.5 seconds (延时0.5s)

#Draw a blue rectangle (绘制一个蓝色的矩形)
img.draw_rectangle((20, 20, lcd.width()-40, lcd.height()-40), fill=True, color=(0, 0, 250))

#Write string (写字符串)
img.draw_string(50, 25, "Hello Hiwonder", color=(255, 255, 255), scale=2)

lcd.display(img) #Display the image (显示图像)
time.sleep(0.5) #Delay for 0.5 seconds (延时0.5s)

#Draw a rectangle at (50, 60) with width 150 and height 150, in red color, 2-pixel line width, not filled (在图像上绘制一个矩形，(50, 60)，宽度150，高度150，使用红颜色，线宽为2像素，不填充)
img.draw_rectangle(70, 100, 200, 100, color=(100, 0, 0), thickness=3, fill=False)

lcd.display(img) #Display the image (显示图像)
time.sleep(0.5) #Delay for 0.5 seconds (延时0.5s)


#Draw a line from (50, 50) to (200, 50), using green color, 5-pixel line width (画线，在图像上绘制一条线段，(50, 50)至(200, 50)，使用绿色颜色，线宽为5像素)
img.draw_line(70, 80, 270, 50, color=(0, 255, 0), thickness=10)

lcd.display(img) #Display the image (显示图像)
time.sleep(0.5) #Delay for 0.5 seconds (延时0.5s)


#Draw a circle centered at (125, 135) with radius 50, in white color, 2-pixel line width, not filled (绘制一个圆，中心坐标为(125, 135)，半径为50，使用白色颜色，线宽为2像素，不填充)
img.draw_circle(170, 150, 40, color=(255, 255, 255), thickness=2, fill=False)

lcd.display(img) #Display the image (显示图像)








