'''
@file:    multi_label.py
@company: Hiwonder
@author:  CuZn
@date:    2023-08-21
@description: Draw a multi-tab layout UI using LVGL (通过LVGL绘制多标签布局UI)
'''


#Import LVGL control module (载入LVGL控制模块)
import lvgl as lv
#Import LVGL helper control module (载入LVGL辅助控制模块)
import lvgl_helper as lv_h
#Import LCD control module (载入LCD控制模块)
import lcd
#Import time control module (载入时间控制模块)
import time
#Import LCD touch control module (载入LCD屏幕触摸控制模块)
import touchscreen as lt


#Initialize LCD (初始化LCD)
lcd.init()
#Initialize touch module (初始化触摸模块)
lt.init()
#Initialize LVGL (初始化LVGL)
lv.init()


#Create LVGL display buffer object (创建LVGL显示缓冲区对象)
dis_buf_obj = lv.disp_buf_t()
#Create memory for display buffer (创建显示缓冲区的内存)
dis_buf = bytearray(320*10)
#Initialize buffer (初始化缓冲区)
lv.disp_buf_init(dis_buf_obj, dis_buf, None, len(dis_buf)//4)

#Create LVGL display driver object (创建LVGL显示驱动对象)
dis_drv_obj = lv.disp_drv_t()
#Initialize LVGL display driver object (初始化LVGL显示驱动对象)
lv.disp_drv_init(dis_drv_obj)
#Configure display driver's buffer (配置LVGL显示驱动对象的缓冲区)
dis_drv_obj.buffer = dis_buf_obj
#Configure display driver's flush function (配置LVGL显示驱动对象的刷新函数)
dis_drv_obj.flush_cb = lv_h.flush
#Set display driver horizontal and vertical resolutions to 320 and 240 (设置显示驱动的水平分辨率和垂直分辨率分别为 320 和 240)
dis_drv_obj.hor_res = 320
dis_drv_obj.ver_res = 240
#Register display driver to LVGL (将显示驱动对象注册到LVGL中,供LVGL使用)
lv.disp_drv_register(dis_drv_obj)


#Create LVGL input device driver object (创建LVGL输入设备驱动对象)
in_drv_obj = lv.indev_drv_t()
#Initialize input device driver object (初始化输入设备驱动对象)
lv.indev_drv_init(in_drv_obj)
#Set input device type to pointer (touch screen) (设置输入设备类型为指针（触摸屏）)
in_drv_obj.type = lv.INDEV_TYPE.POINTER
#Set input device driver's read callback function (设置输入设备驱动的读取回调函数)
in_drv_obj.read_cb = lv_h.read
#Register input device driver to LVGL (将输入设备驱动对象注册到LVGL中,供LVGL使用)
lv.indev_drv_register(in_drv_obj)


#Button objects (按键对象)
class Page_Buttons:
    def __init__(self, app, page):
        self.app = app
        self.page = page

        self.counter = 0

        #Create left button (创建左按键)
        self.btn_left = lv.btn(page)
        self.btn_left.set_size(100,60)
        self.btn_left.align(page, lv.ALIGN.IN_TOP_LEFT, 40, 50)
        self.btn_left_label = lv.label(self.btn_left)
        self.btn_left_label.set_text('++')
        self.btn_left.set_event_cb(self.on_left_btn_cb)


        #Create right button (创建右按键)
        self.btn_right = lv.btn(page)
        self.btn_right.set_size(100,60)
        self.btn_right.align(page, lv.ALIGN.IN_TOP_RIGHT, -40, 50)
        self.btn_right_label = lv.label(self.btn_right)
        self.btn_right_label.set_text('--')
        self.btn_right.set_event_cb(self.on_right_btn_cb)


    #Left button callback function (左按键回调函数)
    def on_left_btn_cb(self, obj, event):
        if event == lv.EVENT.CLICKED:
            self.counter += 1
            self.btn_left_label.set_text(str(self.counter))
            self.btn_right_label.set_text(str(self.counter))

    #Right button callback function (右按键回调函数)
    def on_right_btn_cb(self, obj, event):
        if event == lv.EVENT.CLICKED:
            self.counter -= 1
            self.btn_left_label.set_text(str(self.counter))
            self.btn_right_label.set_text(str(self.counter))

#Slider class (滑条类)
class Page_Slider:
    def __init__(self, app, page):
        self.app = app
        self.page = page

        # slider
        self.slider = lv.slider(page)
        self.slider.align(page, lv.ALIGN.CENTER, 0, 0)
        self.slider_label = lv.label(page)
        self.slider_label.align(self.slider, lv.ALIGN.CENTER, 0, -20)
        self.slider.set_event_cb(self.on_slider_changed)
        self.on_slider_changed(None)

    def on_slider_changed(self, obj=None, event=-1):
        self.slider_label.set_text(str(self.slider.get_value()))

#Define animation effect class (定义动画效果类)
class Anim(lv.anim_t):
    def __init__(self, obj, val, size, exec_cb, path_cb, time=500, playback = False, ready_cb=None):
        super().__init__()
        lv.anim_init(self)
        lv.anim_set_time(self, time, 0)
        lv.anim_set_values(self, val, val+size)
        if callable(exec_cb):
            lv.anim_set_custom_exec_cb(self, exec_cb)
        else:
            lv.anim_set_exec_cb(self, obj, exec_cb)
        lv.anim_set_path_cb(self, path_cb )
        if playback: lv.anim_set_playback(self, 0)
        if ready_cb: lv.anim_set_ready_cb(self, ready_cb)
        lv.anim_create(self)


#Define chart class (定义图表类)
class AnimatedChart(lv.chart):

    #Define initialization function (定义初始化函数)
    def __init__(self, parent, val, size):
        super().__init__(parent)
        self.val = val
        self.size = size
        self.max = 2000
        self.min = 500
        self.factor = 100
        self.anim_phase1()

    #Define animation effect 1 (定义动画效果1)
    def anim_phase1(self):
        Anim(
            self,
            self.val,
            self.size,
            lambda a, val: self.set_range(0, val),
            lv.anim_path_ease_in,
            ready_cb=lambda a:self.anim_phase2(),
            time=(self.max * self.factor) // 100)

    #Define animation effect 2 (定义动画效果2)
    def anim_phase2(self):
        Anim(
            self,
            self.val+self.size,
            -self.size,
            lambda a, val: self.set_range(0, val),
            lv.anim_path_ease_out,
            ready_cb=lambda a:self.anim_phase1(),
            time=(self.min * self.factor) // 100)


#Create chart page class (创建图表页 类)
class Page_Chart():
    #Initialize chart page (图表页的初始化)
    def __init__(self, app, page):
        self.app = app
        self.page = page

        self.chart = AnimatedChart(page, 100, 1000)
        self.chart.set_width(page.get_width() - 100)
        self.chart.set_height(page.get_height() - 30)
        self.chart.align(page, lv.ALIGN.CENTER, 0, 0)
        self.series1 = self.chart.add_series(lv.color_hex(0xFF0000))
        self.chart.set_type(self.chart.TYPE.POINT | self.chart.TYPE.LINE)
        self.chart.set_series_width(3)
        self.chart.set_range(0,100)
        self.chart.init_points(self.series1, 10)
        self.chart.set_points(self.series1, [10,20,30,20,10,40,50,80,95,80])
        self.chart.set_x_tick_texts('a\nb\nc\nd\ne', 2, lv.chart.AXIS.DRAW_LAST_TICK)
        self.chart.set_x_tick_length(10, 5)
        self.chart.set_y_tick_texts('1\n2\n3\n4\n5', 2, lv.chart.AXIS.DRAW_LAST_TICK)
        self.chart.set_y_tick_length(10, 5)
        self.chart.set_div_line_count(3, 3)
        self.chart.set_margin(30)

        self.slider = lv.slider(page)
        self.slider.align(self.chart, lv.ALIGN.OUT_RIGHT_TOP, 10, 0)
        self.slider.set_width(30)
        self.slider.set_height(self.chart.get_height())
        self.slider.set_range(10, 200)
        self.slider.set_value(self.chart.factor, 0)
        self.slider.set_event_cb(self.on_slider_changed)

    #Slider callback function (滑条的回调函数)
    def on_slider_changed(self, obj=None, event=-1):
        self.chart.factor = self.slider.get_value()
        if self.slider.get_value() > 50:
            self.chart.set_type(self.chart.TYPE.COLUMN) #Column chart(柱状图)
        else:
            self.chart.set_type(self.chart.TYPE.POINT | self.chart.TYPE.LINE) #Line chart (线性图)


class Screen_Main(lv.obj):
    def __init__(self, app, *args, **kwds):
        self.app = app
        super().__init__(*args, **kwds)

        self.tabview = lv.tabview(self)
        self.tabview.set_style(lv.tabview.STYLE.BG, lv.style_plain_color)
        #bg_style = lv.style_plain_color.copy()
        #bg_style.body.main_color = lv.color_hex(0xE0E0E0)  # Light gray color (浅灰色)
        #self.tabview.set_style(lv.tabview.STYLE.BG, bg_style)

        #Define and add label objects (定义并添加标签对象)
        self.page_buttons = Page_Buttons(self.app, self.tabview.add_tab('button'))
        self.page_slider = Page_Slider(self.app, self.tabview.add_tab('slider'))
        self.page_chart = Page_Chart(self.app, self.tabview.add_tab('chart'))


#Create a window display object (创建一个窗口显示对象)
screen_main = Screen_Main(lv.obj())

#Load window to LCD (将窗口加载到LCD上)
lv.scr_load(screen_main)



#Save current time (保存当前时间)
time_old = time.ticks_ms()
#loop
while True:
    #Check if current time minus last time > 5 ms to control loop frequency (检查当前时间是否与上一次计时时间相差大于 5 毫秒，以控制循环的频率)
    if time.ticks_ms()-time_old > 5:
        #Update last time to current time (将计时时间更新为当前时间)
        time_old = time.ticks_ms()
        #Call LVGL task handler (调用LVGL的任务)
        lv.task_handler()
        #Add 5 ms to LVGL internal tick to ensure smooth operation (给LVGL内部时间计数器加5ms，保证LVGL正常工作)
        lv.tick_inc(5)




