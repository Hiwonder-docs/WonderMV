'''
@file:    gauge.py
@company: Hiwonder
@author:  CuZn
@date:    2023-12-06
@description: Draw a pointer gauge using LVGL (通过LVGL绘制指针仪表)
'''


#Import LVGL control module (载入LVGL控制模块)
import lvgl as lv
#Import LVGL helper control module (载入LVGL辅助控制模块)
import lvgl_helper as lv_h
#Import LCD control module (载入LCD控制模块)
import lcd
#Import time control module (载入时间控制模块)
import time
#Import timer module (载入定时器模块)
from machine import Timer
#Import LCD touch control module (载入LCD屏幕触摸控制模块)
import touchscreen as lt


#Initialize LCD (初始化LCD)
lcd.init()
#Initialize touch module (初始化触摸模块)
lt.init()
#Initialize LVGL (初始化LVGL)
lv.init()


#Create LVGL display buffer object (创建LVGL显示缓冲区对象)
dis_buf_obj = lv.disp_buf_t()
#Create memory for display buffer (创建显示缓冲区的内存)
dis_buf = bytearray(320*10)
#Initialize buffer (初始化缓冲区)
lv.disp_buf_init(dis_buf_obj, dis_buf, None, len(dis_buf)//4)

#Create LVGL display driver object (创建LVGL显示驱动对象)
dis_drv_obj = lv.disp_drv_t()
#Initialize LVGL display driver object (初始化LVGL显示驱动对象)
lv.disp_drv_init(dis_drv_obj)
#Configure display driver's buffer (配置LVGL显示驱动对象的缓冲区)
dis_drv_obj.buffer = dis_buf_obj
#Configure display driver's flush function (配置LVGL显示驱动对象的刷新函数)
dis_drv_obj.flush_cb = lv_h.flush
#Set display driver horizontal and vertical resolutions to 320 and 240 (设置显示驱动的水平分辨率和垂直分辨率分别为320和240)
dis_drv_obj.hor_res = 320
dis_drv_obj.ver_res = 240
#Register display driver to LVGL (将显示驱动对象注册到LVGL中,供LVGL使用)
lv.disp_drv_register(dis_drv_obj)


#Create window object (创建窗口对象)
screen = lv.obj()


color = lv.color_t()
color.ch.blue = 0
color.ch.red = 255
ga = lv.gauge(screen)
ga.set_needle_count(1,color)
ga.set_value(0,50)
ga.set_range(0,100)
ga.set_critical_value(80)
ga.set_scale(180,11,11)
#typle = ga.get_typle()
ga.align(screen, lv.ALIGN.CENTER, 0, 30)

#Load window onto LCD (将窗口加载到LCD上)
lv.scr_load(screen)



#Save current time (保存当前时间)
time_old = time.ticks_ms()
value = 0
count = 0

#loop
while True:
    #Check if current time minus last time > 5 ms to control loop frequency (检查当前时间是否与上一次计时时间相差大于 5 毫秒，以控制循环的频率)
    if time.ticks_ms()-time_old > 5:
        #Update last time to current time (将计时时间更新为当前时间)
        time_old = time.ticks_ms()
        if count > 6:
            ga.set_value(0,value)
            value = value + 1
            if value > 100 :
                value = 0
            count = 0
        count = count + 1
        #Call LVGL task handler (调用LVGL的任务)
        lv.task_handler()
        #Add 5 ms to LVGL internal tick to ensure smooth operation (给LVGL内部时间计数器加5ms，保证LVGL正常工作)
        lv.tick_inc(5)



