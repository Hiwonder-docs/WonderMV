'''
@file:    button.py
@company: Hiwonder
@author:  CuZn
@date:    2023-08-18
@description: Create and use buttons with LVGL (通过LVGL库创建并使用按键)
'''

#Import LVGL control module (载入LVGL控制模块)
import lvgl as lv
#Import LVGL helper control module (载入LVGL辅助控制模块)
import lvgl_helper as lv_h
#Import LCD control module (载入LCD控制模块)
import lcd
#Import time control module (载入时间控制模块)
import time
#Import timer module (载入定时器模块)
from machine import Timer
#Import LCD touch screen control module (载入LCD屏幕触摸控制模块)
import touchscreen as ts


#Initialize LCD (初始化LCD)
lcd.init()
#Initialize touch module (初始化触摸模块)
ts.init()
#Initialize LVGL (初始化LVGL)
lv.init()


#Create LVGL display buffer object (创建LVGL显示缓冲区对象)
dis_buf_obj = lv.disp_buf_t()
#Create memory for display buffer (创建显示缓冲区的内存)
dis_buf = bytearray(320*10)
#Initialize display buffer (初始化缓冲区)
lv.disp_buf_init(dis_buf_obj, dis_buf, None, len(dis_buf)//4)

#Create LVGL display driver object (创建LVGL显示驱动对象)
dis_drv_obj = lv.disp_drv_t()
#Initialize LVGL display driver object (初始化LVGL显示驱动对象)
lv.disp_drv_init(dis_drv_obj)
#Configure LVGL display driver buffer (配置LVGL显示驱动对象的缓冲区)
dis_drv_obj.buffer = dis_buf_obj
#Configure LVGL display driver flush callback (配置LVGL显示驱动对象的刷新函数)
dis_drv_obj.flush_cb = lv_h.flush
#Set display driver horizontal resolution and vertical resolution to 320 and 240 (设置显示驱动的水平分辨率和垂直分辨率分别为320和240)
dis_drv_obj.hor_res = 320
dis_drv_obj.ver_res = 240
#Register display driver object to LVGL (将显示驱动对象注册到LVGL中,供LVGL使用)
lv.disp_drv_register(dis_drv_obj)


#Create LVGL input device driver object (创建LVGL输入设备驱动对象)
in_drv_obj = lv.indev_drv_t()
#Create LVGL input device driver object (创建LVGL输入设备驱动对象)
lv.indev_drv_init(in_drv_obj)
#Set input device type to pointer (touch screen) (设置输入设备类型为指针（触摸屏）)
in_drv_obj.type = lv.INDEV_TYPE.POINTER
#Set input device driver read callback (设置输入设备驱动的读取回调函数)
in_drv_obj.read_cb = lv_h.read
#Register input device driver object to LVGL (将输入设备驱动对象注册到LVGL中,供LVGL使用)
lv.indev_drv_register(in_drv_obj)


#Define click counter (定义跟踪点击次数)
count = 0

# Left button release event callback function (左边按钮的释放事件回调函数)
def on_left_btn_cb(obj, event):
    global count
    if event == lv.EVENT.RELEASED:
        count += 1
        label_left.set_text(str(count))
        label_right.set_text(str(count))
        print("Button Press:", count)

# Right button click event callback function (右边按钮的点击事件回调函数)
def on_right_btn_cb(obj, event):
    global count
    if event == lv.EVENT.CLICKED:
        count -= 1
        label_left.set_text(str(count))
        label_right.set_text(str(count))
        print("Button Press:", count)


#Create LVGL window object (创建LVGL窗口对象)
scr = lv.obj()

# Create left button (创建左边的按钮)
btn_left = lv.btn(scr)
#Set alignment to top left with offset (10,10) (设置为左上角对齐，偏移（10,10）)
btn_left.align(None, lv.ALIGN.IN_TOP_LEFT, 30, 80)
#Create text on button (在按钮上创建一个文本)
label_left = lv.label(btn_left)
#Set label size to 20x20 pixels (设置标签的大小为20x20像素)
label_left.set_size(20,20)
#Set text content (设置文本内容)
label_left.set_text("++")
#Set button callback function (设置按钮的回调函数)
btn_left.set_event_cb(on_left_btn_cb)

# Create right button (创建右边的按钮)
btn_right = lv.btn(scr)
#Set alignment to top right with offset (-10,10) (设置为右上角对齐，偏移（-10,10）)
btn_right.align(None, lv.ALIGN.IN_TOP_RIGHT, -30, 80)
label_right = lv.label(btn_right)
label_right.set_size(20,20)
label_right.set_text("--")
btn_right.set_event_cb(on_right_btn_cb)

#Load window to LCD (将窗口加载到LCD上)
lv.scr_load(scr)

#Save current time (保存当前时间)
tim = time.ticks_ms()
#loop
while True:
    #Check if current time minus last time > 5ms to control loop frequency (检查当前时间是否与上一次计时时间相差大于5毫秒，以控制循环的频率)
    if time.ticks_ms()-tim > 5:
        #Update last time to current time (将计时时间更新为当前时间)
        tim = time.ticks_ms()
        #Call LVGL task handler (调用LVGL的任务)
        lv.task_handler()
        #Add 5ms to LVGL internal tick (给LVGL内部时间计数器加5ms，保证LVGL正常工作)
        lv.tick_inc(5)



