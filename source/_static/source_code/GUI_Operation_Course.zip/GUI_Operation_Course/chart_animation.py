'''
@file:    chart_animation.py
@company: Hiwonder
@author:  CuZn
@date:    2023-08-18
@description: Create chart animation with LVGL (通过LVGL绘制图表动画)
'''


#Import LVGL control module (载入LVGL控制模块)
import lvgl as lv
#Import LVGL helper control module (载入LVGL辅助控制模块)
import lvgl_helper as lv_h
#Import LCD control module (载入LCD控制模块)
import lcd
#Import time control module (载入时间控制模块)
import time
#Import LCD touch screen control module (载入LCD屏幕触摸控制模块)
import touchscreen as lt


#Initialize LCD (初始化LCD)
lcd.init()
#Initialize touch module (初始化触摸模块)
lt.init()
#Initialize LVGL (初始化LVGL)
lv.init()


#Create LVGL display buffer object (创建LVGL显示缓冲区对象)
dis_buf_obj = lv.disp_buf_t()
#Create memory for display buffer (创建显示缓冲区的内存)
dis_buf = bytearray(320*10)
#Initialize display buffer (初始化缓冲区)
lv.disp_buf_init(dis_buf_obj, dis_buf, None, len(dis_buf)//4)

#Create LVGL display driver object (创建LVGL显示驱动对象)
dis_drv_obj = lv.disp_drv_t()
#Initialize LVGL display driver object (初始化LVGL显示驱动对象)
lv.disp_drv_init(dis_drv_obj)
#Configure LVGL display driver buffer (配置LVGL显示驱动对象的缓冲区)
dis_drv_obj.buffer = dis_buf_obj
#Configure LVGL display driver flush callback (配置LVGL显示驱动对象的刷新函数)
dis_drv_obj.flush_cb = lv_h.flush
#Set display driver horizontal and vertical resolution to 320 and 240 (设置显示驱动的水平分辨率和垂直分辨率分别为320和240)
dis_drv_obj.hor_res = 320
dis_drv_obj.ver_res = 240
#Register display driver to LVGL (将显示驱动对象注册到LVGL中,供LVGL使用)
lv.disp_drv_register(dis_drv_obj)


#Create LVGL input device driver object (创建LVGL输入设备驱动对象)
in_drv_obj = lv.indev_drv_t()
#Initialize input device driver object (初始化输入设备驱动对象)
lv.indev_drv_init(in_drv_obj)
#Set input device type to pointer (touch screen) (设置输入设备类型为指针（触摸屏）)
in_drv_obj.type = lv.INDEV_TYPE.POINTER
#Set input device driver read callback (设置输入设备驱动的读取回调函数)
in_drv_obj.read_cb = lv_h.read
#Register input device driver to LVGL (将输入设备驱动对象注册到LVGL中,供LVGL使用)
lv.indev_drv_register(in_drv_obj)


'''
Define Anim class inheriting from lv.anim_t (定义一个名为 Anim 的动画类，继承自 lv.anim_t 类)

__init__ initializes the animation object(__init__ 初始化函数，用于创建动画对象。)
参数含义如下：
obj: object to animate(obj：要应用动画的对象（界面元素）。)
val: start value(val：动画的起始值。)
size: value change range(size：动画值的变化大小。)
exec_cb: animation execution callback(exec_cb：动画执行的回调函数或方法。)
path_cb: animation path function(path_cb：动画的路径函数。)
time: animation time in ms (default 500)(time：动画执行的时间（以毫秒为单位），默认为 500 毫秒。)
playback: playback mode (default False)(playback：是否使用回放模式，默认为 False。)
ready_cb: callback after animation completes(ready_cb：动画完成后的回调函数。)
'''
class Anim(lv.anim_t):
    def __init__(self, obj, val, size, exec_cb, path_cb, time=500, playback = False, ready_cb=None):
        super().__init__()
        lv.anim_init(self)
        lv.anim_set_time(self, time, 0)
        lv.anim_set_values(self, val, val+size)
        if callable(exec_cb):
            lv.anim_set_custom_exec_cb(self, exec_cb)
        else:
            lv.anim_set_exec_cb(self, obj, exec_cb)
        lv.anim_set_path_cb(self, path_cb )
        if playback: lv.anim_set_playback(self, 0)
        if ready_cb: lv.anim_set_ready_cb(self, ready_cb)
        lv.anim_create(self)

'''
Define AnimatedChart class inheriting from lv.chart (定义 AnimatedChart 类, 继承自 lv.chart)
Used to create a chart object with animation effects(用于创建一个带有动画效果的图表对象)
'''
class AnimatedChart(lv.chart):
    '''
    Initialization method to create the animated chart object. Parameters are as follows:(初始化方法，用于创建带有动画效果的图表对象。参数如下：)
    parent: The parent object of the chart, i.e., the container to which the chart will be added.(parent：图表的父对象，即图表要添加到的父容器。)
    val: The starting value of the chart.(val：图表的起始值。)
    size: The range of value change of the chart.(size：图表值的变化大小。)
    '''
    def __init__(self, parent, val, size):
        #Call the parent class’s initialization method to complete the chart object setup and bind it to the parent object(调用父类的初始化方法，完成图表对象的初始化，并绑定到parent对象中)
        super().__init__(parent)
        self.val = val
        self.size = size
        self.max = 2000
        self.min = 500
        self.factor = 100
        #Execute animation effect function 1(执行动画效果函数1)
        self.anim_phase1()

    '''
    animation1: animate chart range using ease_in (动画效果函数1，用于改变图表的范围)
    The chart range will gradually change following the specified path function lv.anim_path_ease_in.（图表的范围（range）将按照指定的路径函数 lv.anim_path_ease_in 逐渐变化）
    '''
    def anim_phase1(self):
        Anim(
            self,
            self.val,
            self.size,
            lambda a, val: self.set_range(0, val),
            #A built-in LVGL path function: starts slow and then gradually accelerates, creating a smooth transition effect (LVGL 中的一个内置路径函数：让动画的变化速度在开始时较慢，然后逐渐加速，呈现出一种平滑的过渡效果)
            lv.anim_path_ease_in,
            ready_cb=lambda a:self.anim_phase2(),
            time= (self.max * self.factor) // 100 )
    '''
    animation2: animate chart range using ease_out (动画效果函数2，用于改变图表的范围)
    In this stage, the chart range will gradually change following the specified path function lv.anim_path_ease_out (在这个阶段内，图表的范围将按照指定的路径函数 lv.anim_path_ease_out 逐渐变化)
    '''
    def anim_phase2(self):
        Anim(
            self,
            self.val+self.size,
            -self.size,
            lambda a, val: self.set_range(0, val),
            #A built-in LVGL path function: changes quickly at the beginning and then gradually slows down, creating a smooth deceleration transition effect (LVGL 中的一个内置路径函数：在动画的初始阶段变化较快，然后逐渐减速，呈现出一种平滑的减速过渡效果)
            lv.anim_path_ease_out,
            ready_cb=lambda a:self.anim_phase1(),
            time= (self.min * self.factor) // 100 )


#Create window object (创建窗口对象)
screen = lv.obj()
#Create chart object, start value 100, change size 1000 (创建图表对象，起始值为100，变化大小为1000)
chart_obj = AnimatedChart(screen, 100, 1000)
#Set width and height (设置宽度和高度)
chart_obj.set_width(screen.get_width() - 100)
chart_obj.set_height(screen.get_height() - 60)
#Set center alignment (设置水平和垂直居中对齐)
chart_obj.align(screen, lv.ALIGN.CENTER, 0, 0)
#Add data series (series1) and set color (添加一个数据系列并设置颜色)
series1 = chart_obj.add_series(lv.color_hex(0xFF0000))

#Set the type to column chart; options: point: chart_obj.TYPE.POINT, line: chart_obj.TYPE.LINE, column: chart_obj.TYPE.COLUMN (设置类型为柱状图；点：chart_obj.TYPE.POINT，线：chart_obj.TYPE.LINE，柱状：chart_obj.TYPE.COLUMN)
chart_obj.set_type(chart_obj.TYPE.COLUMN) #柱状图

#Set series line width to 5 (设置数据系列线宽度为5)
chart_obj.set_series_width(5)
#Set chart range (设置图表的显示范围)
chart_obj.set_range(0,100)
#Initialize data series series1 and specify the number of points (初始化数据系列 series1，指定点的个数)
chart_obj.init_points(series1, 15)
#Set data points for data series series1 (设置数据系列 series1 的数据点)
chart_obj.set_points(series1, [5,30,35,70,90,40,20,30,75,90,80,75,90,95,100])
#Set x-axis tick text, length, and divider lines (设置 x 轴刻度文本、长度和分割线)
chart_obj.set_x_tick_texts('a\nb\nc\nd\ne', 2, lv.chart.AXIS.DRAW_LAST_TICK)
chart_obj.set_x_tick_length(10, 5)
#Set y-axis tick text, length, and divider lines (设置 y 轴刻度文本、长度和分割线)
chart_obj.set_y_tick_texts('5\n4\n3\n2\n1', 2, lv.chart.AXIS.DRAW_LAST_TICK)
chart_obj.set_y_tick_length(10, 5)
#Set the number of divider lines (设置分割线的数量)
chart_obj.set_div_line_count(3, 3)
#Set chart margins (设置图表的边距)
chart_obj.set_margin(30)

'''
Slider touch callback function, called when slider value changes (触摸滑条时的回调函数，当滑条的值发生变化时会被调用)
If value is less than or equal to 50, change to line chart. If value is greater than 50, change to column chart (当值小于等于50，则变为线性图，当值大于50，则变为柱状图)
'''
def on_slider_changed(self, obj=None, event=-1):
    chart_obj.factor = slider_obj.get_value()
    if slider_obj.get_value() > 50:
        chart_obj.set_type(chart_obj.TYPE.COLUMN) #Column chart (柱状图)
    else:
        chart_obj.set_type(chart_obj.TYPE.POINT | chart_obj.TYPE.LINE) #Line chart (线性图)



#Create slider object (创建滑条对象)
slider_obj = lv.slider(screen)
#Set external alignment to top right, offset (10, 0) (设置右上方外部对齐，水平和垂直偏移量为(10, 0))
slider_obj.align(chart_obj, lv.ALIGN.OUT_RIGHT_TOP, 10, 0)
#Set slider width and height (设置滑条的宽度、高度)
slider_obj.set_width(30)
slider_obj.set_height(chart_obj.get_height())
#Set slider value range (设置滑条的取值范围)
slider_obj.set_range(10, 100)
#Set current value of slider (设置滑条的当前值)
slider_obj.set_value(chart_obj.factor, 0)
#Set slider event callback function (设置滑条的事件回调函数)
slider_obj.set_event_cb(on_slider_changed)


#Load window to LCD (将窗口加载到LCD上)
lv.scr_load(screen)


#Save current time (保存当前时间)
time_old = time.ticks_ms()
#loop
while True:
    #Check if current time minus last time > 5 ms to control loop frequency (检查当前时间是否与上一次计时时间相差大于 5 毫秒，以控制循环的频率)
    if time.ticks_ms()-time_old > 5:
        #Update last time to current time (将计时时间更新为当前时间)
        time_old = time.ticks_ms()
        #Call LVGL task handler (调用LVGL的任务)
        lv.task_handler()
        #Add 5 ms to LVGL internal tick to keep it running properly (给LVGL内部时间计数器加5ms，保证LVGL正常工作)
        lv.tick_inc(5)




