'''
@file:    draw_graph.py
@company: Hiwonder
@author:  CuZn
@date:    2023-08-18
@description: Create slider using LVGL (通过LVGL绘制滑动条)
'''


#Import LVGL control module (载入LVGL控制模块)
import lvgl as lv
#Import LVGL helper control module (载入LVGL辅助控制模块)
import lvgl_helper as lv_h
#Import LCD control module (载入LCD控制模块)
import lcd
#Import time control module (载入时间控制模块)
import time
#Import timer module (载入定时器模块)
from machine import Timer
#Import LCD touch screen control module (载入LCD屏幕触摸控制模块)
import touchscreen as lt


#Initialize LCD (初始化LCD)
lcd.init()
#Initialize touch module (初始化触摸模块)
lt.init()
#Initialize LVGL (初始化LVGL)
lv.init()


#Create LVGL display buffer object (创建LVGL显示缓冲区对象)
dis_buf_obj = lv.disp_buf_t()
#Create memory for display buffer (创建显示缓冲区的内存)
dis_buf = bytearray(320*10)
#Initialize display buffer (初始化缓冲区)
lv.disp_buf_init(dis_buf_obj, dis_buf, None, len(dis_buf)//4)

#Create LVGL display driver object (创建LVGL显示驱动对象)
dis_drv_obj = lv.disp_drv_t()
#Initialize LVGL display driver object (初始化LVGL显示驱动对象)
lv.disp_drv_init(dis_drv_obj)
#Configure LVGL display driver buffer (配置LVGL显示驱动对象的缓冲区)
dis_drv_obj.buffer = dis_buf_obj
#Configure LVGL display driver flush callback (配置LVGL显示驱动对象的刷新函数)
dis_drv_obj.flush_cb = lv_h.flush
#Set display driver horizontal resolution and vertical resolution to 320 and 240 (设置显示驱动的水平分辨率和垂直分辨率分别为320和240)
dis_drv_obj.hor_res = 320
dis_drv_obj.ver_res = 240
#Register display driver object to LVGL (将显示驱动对象注册到LVGL中,供LVGL使用)
lv.disp_drv_register(dis_drv_obj)


#Create LVGL input device driver object (创建LVGL输入设备驱动对象)
in_drv_obj = lv.indev_drv_t()
#Initialize input device driver object (初始化输入设备驱动对象)
lv.indev_drv_init(in_drv_obj)
#Set input device type to pointer (touch screen) (设置输入设备类型为指针（触摸屏）)
in_drv_obj.type = lv.INDEV_TYPE.POINTER
#Set input device driver read callback (设置输入设备驱动的读取回调函数)
in_drv_obj.read_cb = lv_h.read
#Register input device driver object to LVGL (将输入设备驱动对象注册到LVGL中,供LVGL使用)
lv.indev_drv_register(in_drv_obj)


#Create window object (创建窗口对象)
screen = lv.obj()


#Create label (for displaying slider value) (创建文本，用于显示滑条当前值)
dis_slider_val = lv.label(screen)
#Set alignment to center horizontally and vertically, offset left by 50 and up by 50 (设置水平和垂直都居中对齐，同时水平向左偏移50，垂直向上偏移50)
dis_slider_val.align(lv.scr_act(), lv.ALIGN.CENTER, -10, -50)
#Set label text content (设置文本内容)
dis_slider_val.set_text("Value:50")


#Slider event callback function (触摸滑条时的回调函数)
def on_slider_changed(self, obj=None, event=-1):
    #Get current slider value (获取滑动条当前值)
    slider_val = slider_obj.get_value()
    #Update label text content (更新文本内容)
    dis_slider_val.set_text("Value: %d" % (slider_val))
    #Print value (打印)
    print("slider value: ", slider_val)


#Create slider object (创建滑条对象)
slider_obj = lv.slider(screen)
#Set center alignment (设置居中对齐)
slider_obj.align(lv.scr_act(), lv.ALIGN.CENTER, -20, 0)
#Set width and height (in pixels) (设置宽度、高度（像素）)
slider_obj.set_width(250)
slider_obj.set_height(50)
#Set value range (设置取值范围)
slider_obj.set_range(0, 100)
#Set initial value to 50, parameter 2: 1 for animation, 0 for no animation (设置初始值为50，参数2为过渡动画，1为有，0为无)
slider_obj.set_value(50, 1)
#Set slider event callback (设置滑条的回调函数)
slider_obj.set_event_cb(on_slider_changed)


#Load window to LCD (将窗口加载到LCD上)
lv.scr_load(screen)

#Save current time (保存当前时间)
time_old = time.ticks_ms()
#loop
while True:
    #Check if current time minus last time > 5 ms to control loop frequency (检查当前时间是否与上一次计时时间相差大于5毫秒，以控制循环的频率)
    if time.ticks_ms()-time_old > 5:
        #Update last time to current time (将计时时间更新为当前时间)
        time_old = time.ticks_ms()
        #Call LVGL task handler (调用LVGL的任务)
        lv.task_handler()
        #Add 5 ms to LVGL internal tick (给LVGL内部时间计数器加5ms，保证LVGL正常工作)
        lv.tick_inc(5)


