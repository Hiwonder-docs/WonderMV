'''
@file:    key_scan.py
@company: Hiwonder
@author:  CuZn
@date:    2023-09-18
@description: Scan Button 1 and Button 2 separately, print messages, and control LED and fill light on/off respectively (分别扫描按键1、按键2，打印信息，并分别控制LED灯、补光灯亮灭)
'''

#Import button control module (载入按键控制模块)
from hiwonder import hw_key
#Import LED and fill light control modules (载入LED灯、补光灯控制模块)
from hiwonder import hw_led , fill_light
#Import time control module (载入时间控制模块)
import time

#Create button control object (创建按键控制对象)
key = hw_key()

#Create LED control object (创建LED控制对象)
led = hw_led()
#Create fill light control object (创建补光灯控制对象)
f_led = fill_light()

#loop
while True:
    #Check if Button 1 is pressed (获取按键1是否按下)
    state = key.key_scan(1)
    #If pressed (若按下)
    if state:
        led.led_onoff(1)    #Turn LED on (LED开)
    #If released (若松开)
    else:
        led.led_onoff(0)    #Turn LED off (LED关)
    print("key1 state:", state) #Print message (打印信息)

    #Check if Button 2 is pressed (获取按键2是否按下)
    state = key.key_scan(2)
    #If pressed (若按下)
    if state:
        f_led.fill_onoff(1) #Turn fill light on (补光灯开)
    #If released (若松开)
    else:
        f_led.fill_onoff(0) #Turn fill light off (补光灯关)
    print("key2 state:", state) #Print message (打印信息)

    time.sleep_ms(50)   #Delay 50 ms (延时50ms)



