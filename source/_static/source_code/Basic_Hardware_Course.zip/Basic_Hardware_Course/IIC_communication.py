'''
@file:    IIC_communication.py
@company: Hiwonder
@author:  CuZn
@date:    2023-09-22
@description: IIC communication experiment (IIC通讯实验)
'''


from hiwonder import hw_i2c
#Import time control module (载入时间控制模块)
import time
from machine import I2C

#Create I2C object (创建串口对象)
#iic = hw_i2c(freq=100000)
#iic = hw_i2c(hw_i2c.I2C3,freq=100000, scl=18, sda=19)
iic = I2C(I2C.I2C3,freq=100000, scl=18, sda=19)
'''
Note: The touchscreen's I2C and the external I2C interface share the same bus,
# so even if nothing is connected to the external port, one device (the touchscreen) will still be detected
# (注意：touchscreen的i2c 和 外接口的i2c 是同一个，所以外接口不接，也能扫描到一个设备（为touchscreen）)
'''
buf = bytearray(1)
buf[0] = 0x00
add = 0x77
size = 0x02
#loop
while True:
    #Send string (发送字符串)
    print(iic.scan())
    #iic.writeto(add, buf)
    #print(iic.readfrom(add, size))
    #Delay for 0.5 seconds (延时0.5s)
    time.sleep(0.5)




