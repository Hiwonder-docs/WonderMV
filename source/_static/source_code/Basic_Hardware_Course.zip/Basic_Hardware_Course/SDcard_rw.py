'''
@file:    SDcard_rw.py
@company: Hiwonder
@author:  CuZn
@date:    2023-09-18
@description: Read and write photos and text files on SD card (SD卡读取与写入照片和文本文件)
'''

#Import sensor control module (载入传感器控制模块)
import sensor
#Import LCD control module (载入LCD控制模块)
import lcd
#Import image module (载入图像模块)
import image
#Import fill light control module (载入补光灯控制模块)
from hiwonder import fill_light
#Import time control module (载入时间控制模块)
import time



#Create fill light control object (创建补光灯控制对象)
f_led = fill_light()
#Initialize LCD (初始化LCD)
lcd.init()
#Reset sensor (重置传感器)
sensor.reset()


#Set the pixel format of the camera (指定摄像头的像素格式)
sensor.set_pixformat(sensor.RGB565)
#Set the image frame size (设置图像帧大小)
sensor.set_framesize(sensor.QVGA)
#Start sensor in continuous capture mode (启动传感器的连续数据采集模式)
sensor.run(1)
#Skip the first 10 frames to ensure image stability (跳过第一次采集的前10帧图像，确保图像稳定)
sensor.skip_frames(10)

#Turn on fill light (补光灯开)
f_led.fill_onoff(1)

#Delay 3 seconds before taking photo (延时3s后拍照)
time.sleep(3)

'''
 Capture image and save it to SD card (拍摄图像并保存到SD卡中)
'''
#Print message (打印)
print("save image...")
#Image save path — must be under /sd directory, filename can be customized (图像保存路径，要保存在/sd路径下，名字可自由定义)
img_path = "/sd/SDcard_image.jpg"
#Get current image from sensor (获取传感器的当前图像)
img = sensor.snapshot()
#Save the image to the specified path (将图像保存到该路径中)
img.save(img_path)

f_led.fill_onoff(0) #Turn off fill light (补光灯关)

'''
 Read image from SD card and display it on LCD (从SD卡中读取图像并显示在LCD上)
'''
#Print message (打印)
print("read image...")
#Read image from the path (从该路径中读取图像)
img_read = image.Image(img_path)
#Display the image on LCD (在LCD上显示该图像)
lcd.display(img_read)



#Write text file to SD card (文本文件写入SD卡)
file = open ("/sd/SDcard_test.txt", "w")
file.write("This is the test text from SDcard_rw.py \n")
file.write(img_path)
file.close()

#Read text file from SD card (从SD卡读取文本文件)
file = open("/sd/SDcard_test.txt", "r")
print(file.readline())
print(file.readline())
file.close()





