'''
@file:    serial_communication.py
@company: Hiwonder
@author:  CuZn
@date:    2023-08-17
@description: Serial communication experiment (串口通讯实验)
'''


from hiwonder import hw_uart
#Import time control module (载入时间控制模块)
import time

#Create UART (serial) object (创建串口对象)
serial = hw_uart()


#Define string to send (定义发送字符串)
str_buf = [0x01 , 0x02 , 0x03 , 0x04]

#loop
while True:
    #Send string (发送字符串)
    serial.send_bytearray(str_buf)
    bt = serial.rec_bytes()
    print("rec:")
    print(bt)
    #Delay for 0.5 seconds (延时0.5s)
    time.sleep(0.5)




