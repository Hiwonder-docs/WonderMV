'''
@file:    touchscreen_read.py
@company: Hiwonder
@author:  CuZn
@date:    2023-08-17
@description: LCD Display Experiment (LCD显示实验)
'''

#Import LCD touchscreen control module (载入LCD屏幕触摸控制模块)
import touchscreen as ts
#Import LCD control module (载入LCD控制模块)
import lcd
#Import image module (载入图像模块)
import image
#Import time control module (载入时间控制模块)
import time

#Initialize LCD (初始化LCD)
lcd.init()
#Initialize LCDtouch module (初始化LCDtouch模块)
ts.init()

#Get image object (获取图像对象)
img = image.Image()
#Write string on the image (在图像上写字符串)
img.draw_string(50, 50, "Please touch the LCD", color=(200, 200, 0), scale=2)

#Define previous touch state (定义上一次的触摸状态)
(last_status, last_x, last_y) = ts.read()

#loop
while True:
    #Read current touch state (读取当前的触摸状态)
    (status, x, y) = ts.read()

    #If state changed (若有变化)
    if last_status != status:
        #Print current touch state (打印当前的触摸状态)
        print(status, x, y)

    #If state is touch move (若状态为移动触摸)
    if status == ts.STATUS_MOVE:
        #Draw line from (x_last, y_last) to (x, y) (画线 从（x_last, y_last）到（x, y）)
        img.draw_line(last_x, last_y, x, y)
    elif status == ts.STATUS_PRESS: #If state is touch down (若状态为按下触摸)
        img.draw_line(x, y, x, y)

    #Display on LCD (显示在LCD上)
    lcd.display(img)

    #Save current touch state (保存当前的触摸状态)
    last_status = status
    last_x = x
    last_y = y







