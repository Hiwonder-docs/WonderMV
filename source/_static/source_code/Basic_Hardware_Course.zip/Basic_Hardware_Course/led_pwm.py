'''
@file:    led_pwm.py
@company: Hiwonder
@author:  CuZn
@date:    2023-09-18
@description: Use PWM to control the LED to display a breathing light effect (使用PWM控制LED灯显示呼吸灯效果)
'''

#Import timer module and PWM control module (载入定时器模块，PWM控制模块)
from machine import Timer, PWM
#Import time control module (载入时间控制模块)
import time

'''
 Pin description: (引脚说明：)
    LED : 24
'''
output_led_pin = 24

#Create timer object using timer 0 channel 0 in PWM mode (创建定时器对象，使用定时器0的第0通道，模式为PWM)
timer = Timer(Timer.TIMER0, Timer.CHANNEL0, mode=Timer.MODE_PWM)
#Create PWM output object with timer as PWM source, frequency 2000Hz, duty cycle 0%, output pin is output_led_pin (创建PWM输出对象，使用timer作为PWM源，频率2000，占空比为0%，输出引脚为output_led_pin)
pwm = PWM(timer, freq=2000, duty=0, pin=output_led_pin)

#PWM output value (输出的PWM值)
PWM_duty=0
#Direction of brightness change, True means increasing brightness (亮灭的方向，True为亮起)
onoff_dir = True

#loop
while True:
    #If onoff_dir is True (若onoff_dir为True)
    if onoff_dir:
        PWM_duty += 4 #Increase duty cycle by 4 (占空比+4)
    else:   #If onoff_dir is False (若onoff_dir为False)
        PWM_duty -= 4 #Decrease duty cycle by 4 (占空比-4)

    #If duty cycle exceeds 100%, set light to gradually turn off (若占空比大于100%，则设置灯为慢慢灭)
    if PWM_duty > 100:
        PWM_duty = 100
        onoff_dir = False
    elif PWM_duty < 0:  #If duty cycle is less than 0%, set light to gradually turn on (若占空比小于0%，则设置灯慢慢亮起)
        PWM_duty = 0
        onoff_dir = True

    pwm.duty(PWM_duty)  #Set PWM duty cycle (设置PWM占空比)
    time.sleep(0.06)    #Delay 0.06 seconds (延时0.06s)




