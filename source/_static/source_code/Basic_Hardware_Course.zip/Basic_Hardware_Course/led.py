'''
@file:    led.py
@company: Hiwonder
@author:  CuZn
@date:    2023-09-18
@description: Control LED on/off (控制LED灯亮灭)
'''

#Import LED and fill light control modules (载入LED灯、补光灯控制模块)
from hiwonder import hw_led , fill_light
#Import time control module (载入时间控制模块)
import time

#Create LED control object (创建LED控制对象)
led = hw_led()
#Create fill light control object (创建补光灯控制对象)
f_led = fill_light()

#loop
while True:
    '''
    led_onoff() function (led_onoff()函数)
    Parameter 1: On/Off (参数1：开/关)
    0 = Off, 1 = On (0关闭，1开启)
    '''
    led.led_onoff(1)    #Turn LED on (LED开)
    f_led.fill_onoff(0) #Turn fill light off (补光灯关)
    time.sleep(0.5)  #Delay 0.5 seconds (延时0.5s)
    led.led_onoff(0)    #Turn LED off (LED关)
    f_led.fill_onoff(1) #Turn fill light on (补光灯开)
    time.sleep(0.5)  #Delay 0.5 seconds (延时0.5s)

