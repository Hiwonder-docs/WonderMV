'''
@file:    camera_display.py
@company: Hiwonder
@author:  CuZn
@date:    2023-08-17
@description: Display camera image and FPS on LCD, and print FPS (摄像头的图像与帧率显示在LCD上，并打印帧率)
'''

#Import sensor control module (载入传感器控制模块)
import sensor
#Import LCD control module (载入LCD控制模块)
import lcd
#Import time control module (载入时间控制模块)
import time

#Initialize LCD (初始化LCD)
lcd.init()
#Reset sensor (重置传感器)
sensor.reset()

#Set the pixel format of the camera (指定摄像头的像素格式)
sensor.set_pixformat(sensor.RGB565)
#Set the image frame size (设置图像帧大小)
sensor.set_framesize(sensor.QVGA)
#Start sensor in continuous capture mode (启动传感器的连续数据采集模式)
sensor.run(1)
#Skip the first 10 frames to ensure image stability (跳过第一次采集的前10帧图像，确保图像稳定)
sensor.skip_frames(10)

#Create clock object (创建时钟对象)
clock = time.clock()

#Set display orientation to 0° (界面设置为0°显示)
lcd.rotation(0)
lcd.mirror(False)

#loop
while(True):
    #Record current time for FPS calculation (记录当前时间，用于后续计算帧率)
    clock.tick()
    #Get snapshot image from sensor (获取传感器的快照图像)
    img = sensor.snapshot()
    #Get current FPS (获取当前帧率)
    fps = clock.fps()
    #Draw FPS info on the image — this will draw the current FPS value at the top-left corner in green text with a scale of 1.5 (在图像上绘制帧率信息。这将在图像左上角绘制当前帧率值，使用绿色文本，字体缩放比例为1.5)
    img.draw_string(0, 0, "%2.1ffps" %(fps), color=(0, 255, 0), scale=1.5)
    #Display the frame image (显示该帧图像)
    lcd.display(img)
    #Print FPS (打印帧率)
    print(fps)










