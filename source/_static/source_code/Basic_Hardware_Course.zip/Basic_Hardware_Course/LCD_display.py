'''
@file:    LCD_display.py
@company: Hiwonder
@author:  CuZn
@date:    2023-08-17
@description: LCD display experiment (LCD显示实验)
'''

#Import LCD control module (载入LCD控制模块)
import lcd
#Import time control module (载入时间控制模块)
import time

#Initialize LCD (初始化LCD)
lcd.init()
#Clear LCD screen and set background color to blue (清除LCD界面，设置为蓝色)
lcd.clear(lcd.BLUE)


#loop
while True:
    #Clear LCD screen (清除LCD界面)
    lcd.clear(lcd.BLUE)
    #Set display orientation to 0° (界面设置为0°显示)
    lcd.rotation(0)
    #Show string (显示字符串)
    lcd.draw_string(100, 50, "Hello, Hiwonder", lcd.WHITE, lcd.BLUE)
    #Delay for 1 second (延时1s)
    time.sleep(1)


    lcd.clear(lcd.BLUE)
    #Rotate display to 90° (界面旋转为90°显示)
    lcd.rotation(1)
    lcd.draw_string(70, 50, "Hello Hiwonder", lcd.WHITE, lcd.RED)
    time.sleep(1)

    lcd.clear(lcd.BLUE)
    #Rotate display to 180° (界面旋转为180°显示)
    lcd.rotation(2)
    lcd.draw_string(100, 50, "Hello Hiwonder", lcd.WHITE, lcd.GREEN)
    time.sleep(1)

    lcd.clear(lcd.BLUE)
    #Rotate display to -90° (界面旋转为-90°显示)
    lcd.rotation(3)
    lcd.draw_string(70, 50, "Hello Hiwonder", lcd.WHITE, lcd.YELLOW)
    time.sleep(1)

    lcd.clear(lcd.BLUE)
    #Set display orientation back to 0° (界面设置为0°显示)
    lcd.rotation(0)
    lcd.draw_string(100, 100, "Hello Hiwonder", lcd.WHITE, lcd.BLACK)
    time.sleep(1)

