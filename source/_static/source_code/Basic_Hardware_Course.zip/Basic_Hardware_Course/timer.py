'''
@file:    timer.py
@company: Hiwonder
@author:  CuZn
@date:    2023-08-17
@description: Use timer to print periodically, and print with delay in loop, both work independently (使用定时器定时打印，在loop延时打印，两者互不干扰)
'''

#Import timer module (载入定时器模块)
from machine import Timer
#Import time control module (载入时间控制模块)
import time

#Timer callback function (function executed when timer period ends) (定时器回调函数（定时时间到后执行的函数）)
def timeout_callback(timer):
    print("This is timeout_callback")

'''
Create timer object (创建定时器对象，)
Using timer 0(使用 定时器0，)
    Channel 0(第0通道，)
    Period 500 (周期是500，)
    Unit in ms(单位ms，)
    Callback function is timeout_callback (回调函数为timeout_callback，)
    No arguments passed(传入参数 无)
'''
mytimer = Timer(Timer.TIMER0, Timer.CHANNEL0,
            mode=Timer.MODE_PERIODIC, period=500,
            unit=Timer.UNIT_MS, callback=timeout_callback, arg=None)


#Catch errors (捕获error)
try:
    #loop
    while True:
        print("This is loop") #Print (打印)
        time.sleep_ms(200)  #Delay 200 ms (延时200ms)

except: #If an error occurs, it will jump here (若运行出错，会调到这里)
    #Unbind timer (解绑定时器)
    mytimer.deinit()
    #Destroy timer object (销毁定时器对象)
    del mytimer











